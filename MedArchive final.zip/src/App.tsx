import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { supabase } from "./lib/supabase";
import type { Session } from "@supabase/supabase-js";

import Landing from "./pages/Landing";
import Auth from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import Upload from "./pages/Upload";
import Review from "./pages/Review";
import Timeline from "./pages/Timeline";
import Search from "./pages/Search";
import MedicalMemory from "./pages/MedicalMemory";
import AuthGuard from "./components/AuthGuard";
import Seed from "./pages/Seed";

function AppRoutes() {
  const [session, setSession] = useState<Session | null | undefined>(undefined);

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: { subscription } } = supabase.auth.onAuthStateChange((_, s) => setSession(s));
    return () => subscription.unsubscribe();
  }, []);

  if (session === undefined) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div
          className="w-6 h-6 rounded-full border-2 border-t-transparent animate-spin"
          style={{ borderColor: "var(--color-primary)", borderTopColor: "transparent" }}
        />
      </div>
    );
  }

  return (
    <Routes>
      <Route path="/" element={<Landing />} />
      <Route
        path="/auth"
        element={session ? <Navigate to="/dashboard" replace /> : <Auth />}
      />
      <Route
        path="/dashboard"
        element={<AuthGuard><Dashboard /></AuthGuard>}
      />
      <Route
        path="/upload"
        element={<AuthGuard><Upload /></AuthGuard>}
      />
      <Route
        path="/review"
        element={<AuthGuard><Review /></AuthGuard>}
      />
      <Route
        path="/timeline"
        element={<AuthGuard><Timeline /></AuthGuard>}
      />
      <Route
        path="/search"
        element={<AuthGuard><Search /></AuthGuard>}
      />
      <Route
        path="/memory"
        element={<AuthGuard><MedicalMemory /></AuthGuard>}
      />
      <Route path="/seed" element={<Seed />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <AppRoutes />
    </BrowserRouter>
  );
}
