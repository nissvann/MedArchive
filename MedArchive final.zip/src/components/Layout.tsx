import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { supabase } from "../lib/supabase";
import {
  Clock,
  Upload,
  Search,
  MessageSquare,
  LogOut,
  Menu,
  X,
  Heart,
  LayoutDashboard,
} from "lucide-react";

const navItems = [
  { to: "/dashboard", label: "Dashboard", icon: LayoutDashboard },
  { to: "/upload", label: "Upload", icon: Upload },
  { to: "/timeline", label: "Timeline", icon: Clock },
  { to: "/search", label: "Search", icon: Search },
  { to: "/memory", label: "Medical Memory", icon: MessageSquare },
];

export default function Layout({ children }: { children: React.ReactNode }) {
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileOpen, setMobileOpen] = useState(false);

  async function handleLogout() {
    await supabase.auth.signOut();
    navigate("/");
  }

  return (
    <div className="min-h-screen flex flex-col" style={{ background: "var(--color-background)" }}>
      {/* Top nav */}
      <header
        className="sticky top-0 z-40 border-b"
        style={{
          background: "rgba(255,255,255,0.92)",
          backdropFilter: "blur(12px)",
          borderColor: "var(--color-border)",
        }}
      >
        <div className="max-w-6xl mx-auto px-4 h-14 flex items-center justify-between">
          {/* Logo */}
          <Link to="/dashboard" className="flex items-center gap-2">
            <span
              className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: "var(--color-primary)" }}
            >
              <Heart size={14} color="white" fill="white" />
            </span>
            <span className="font-semibold text-sm tracking-tight" style={{ color: "var(--color-foreground)" }}>
              MedArchive
            </span>
          </Link>

          {/* Desktop nav */}
          <nav className="hidden md:flex items-center gap-1">
            {navItems.map(({ to, label, icon: Icon }) => {
              const active = location.pathname === to;
              return (
                <Link
                  key={to}
                  to={to}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors"
                  style={{
                    color: active ? "var(--color-primary)" : "var(--color-muted-foreground)",
                    background: active ? "var(--color-secondary)" : "transparent",
                  }}
                >
                  <Icon size={15} />
                  {label}
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-2">
            <button
              onClick={handleLogout}
              className="hidden md:flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors hover:bg-slate-100"
              style={{ color: "var(--color-muted-foreground)" }}
            >
              <LogOut size={15} />
              Logout
            </button>
            <button
              className="md:hidden p-2 rounded-lg"
              onClick={() => setMobileOpen(!mobileOpen)}
            >
              {mobileOpen ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>

        {/* Mobile nav */}
        {mobileOpen && (
          <div className="md:hidden border-t px-4 py-3 space-y-1" style={{ borderColor: "var(--color-border)" }}>
            {navItems.map(({ to, label, icon: Icon }) => {
              const active = location.pathname === to;
              return (
                <Link
                  key={to}
                  to={to}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium"
                  style={{
                    color: active ? "var(--color-primary)" : "var(--color-foreground)",
                    background: active ? "var(--color-secondary)" : "transparent",
                  }}
                >
                  <Icon size={16} />
                  {label}
                </Link>
              );
            })}
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm font-medium w-full text-left"
              style={{ color: "var(--color-muted-foreground)" }}
            >
              <LogOut size={16} />
              Logout
            </button>
          </div>
        )}
      </header>

      {/* Main content */}
      <main className="flex-1 max-w-6xl mx-auto w-full px-4 py-8 animate-fade-in">
        {children}
      </main>

      {/* Footer */}
      <footer className="border-t py-6" style={{ borderColor: "var(--color-border)" }}>
        <div className="max-w-6xl mx-auto px-4 flex flex-col sm:flex-row items-center justify-between gap-2">
          <p className="text-xs" style={{ color: "var(--color-muted-foreground)" }}>
            MedArchive organizes your records — it is not a medical professional.
          </p>
          <p className="text-xs" style={{ color: "var(--color-muted-foreground)" }}>
            Always consult your doctor for medical decisions.
          </p>
        </div>
      </footer>
    </div>
  );
}
