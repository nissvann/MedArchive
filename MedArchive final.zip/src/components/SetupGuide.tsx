import { useState } from "react";
import { Heart, Copy, Check } from "lucide-react";
import { SETUP_SQL } from "../lib/supabase";

export default function SetupGuide() {
  const [copied, setCopied] = useState(false);

  function copy() {
    navigator.clipboard.writeText(SETUP_SQL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: "var(--color-muted)" }}>
      <div className="max-w-2xl w-full space-y-6">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto" style={{ background: "var(--color-primary)" }}>
            <Heart size={20} color="white" fill="white" />
          </div>
          <h1 className="text-2xl font-semibold" style={{ color: "var(--color-foreground)" }}>MedArchive Setup</h1>
          <p className="text-sm" style={{ color: "var(--color-muted-foreground)" }}>
            Complete these steps to get started.
          </p>
        </div>

        <div className="rounded-2xl p-6 border space-y-4" style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}>
          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 mt-0.5" style={{ background: "var(--color-primary)", color: "white" }}>1</span>
            <div>
              <p className="font-medium text-sm" style={{ color: "var(--color-foreground)" }}>Connect your Supabase project</p>
              <p className="text-sm mt-1" style={{ color: "var(--color-muted-foreground)" }}>
                Use the Supabase connection card in the chat to connect your project. This sets{" "}
                <code className="text-xs bg-slate-100 px-1 rounded">VITE_SUPABASE_URL</code> and{" "}
                <code className="text-xs bg-slate-100 px-1 rounded">VITE_SUPABASE_ANON_KEY</code> automatically.
              </p>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 mt-0.5" style={{ background: "var(--color-primary)", color: "white" }}>2</span>
            <div className="w-full">
              <p className="font-medium text-sm" style={{ color: "var(--color-foreground)" }}>Run the database setup SQL</p>
              <p className="text-sm mt-1 mb-2" style={{ color: "var(--color-muted-foreground)" }}>
                In your Supabase project, go to <strong>SQL Editor</strong> and run:
              </p>
              <div className="relative">
                <pre className="text-xs p-3 rounded-xl overflow-auto max-h-48 bg-slate-900 text-slate-200 leading-relaxed">
                  {SETUP_SQL}
                </pre>
                <button
                  onClick={copy}
                  className="absolute top-2 right-2 p-1.5 rounded-lg transition-colors"
                  style={{ background: "rgba(255,255,255,0.1)" }}
                >
                  {copied ? <Check size={13} color="#4ade80" /> : <Copy size={13} color="white" />}
                </button>
              </div>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <span className="w-6 h-6 rounded-full flex items-center justify-center text-xs font-semibold shrink-0 mt-0.5" style={{ background: "var(--color-primary)", color: "white" }}>3</span>
            <div>
              <p className="font-medium text-sm" style={{ color: "var(--color-foreground)" }}>Add your Gemini API key</p>
              <p className="text-sm mt-1" style={{ color: "var(--color-muted-foreground)" }}>
                Use the API key card in the chat to add your{" "}
                <code className="text-xs bg-slate-100 px-1 rounded">VITE_GEMINI_API_KEY</code>.{" "}
                Get one free at{" "}
                <a href="https://aistudio.google.com" target="_blank" rel="noreferrer" className="underline">
                  Google AI Studio
                </a>
                .
              </p>
            </div>
          </div>
        </div>

        <p className="text-center text-xs" style={{ color: "var(--color-muted-foreground)" }}>
          Reload the page after completing all steps.
        </p>
      </div>
    </div>
  );
}
