import { supabase, EDGE_FN_URL } from "./supabase";
import type { MedicalRecord } from "./types";

// Medical Memory — queries the existing /make-server-7c00bccb/gemini/memory endpoint.
// Document extraction now uses supabase.functions.invoke("summarize-report") in Upload.tsx.

async function authHeaders(): Promise<HeadersInit> {
  const {
    data: { session },
  } = await supabase.auth.getSession();
  if (!session) throw new Error("Not authenticated");
  return {
    "Content-Type": "application/json",
    Authorization: `Bearer ${session.access_token}`,
  };
}

export async function queryMedicalMemory(
  question: string,
  recordsContext: string,
): Promise<string> {
  const headers = await authHeaders();
  const res = await fetch(`${EDGE_FN_URL}/make-server-7c00bccb/gemini/memory`, {
    method: "POST",
    headers,
    body: JSON.stringify({ question, recordsContext }),
  });

  const json = await res.json();
  if (!res.ok) throw new Error(json.error ?? "Medical Memory query failed");
  return (
    json.answer ?? "I couldn't find that information in your saved medical history."
  );
}

export function buildRecordsContext(records: MedicalRecord[]): string {
  if (!records.length) return "No saved medical records.";

  return records
    .map((r, i) => {
      const meds = r.medicines
        ?.map((m) => `${m.name} ${m.dosage} — ${m.instructions}`)
        .join(", ");
      return `Record ${i + 1}:
  Date: ${r.consultation_date ?? "Not recorded"}
  Doctor: ${r.doctor_name ?? "Not recorded"}
  Diagnosis: ${r.diagnosis ?? "Not recorded"}
  Symptoms: ${r.symptoms?.join(", ") || "None recorded"}
  Medicines: ${meds || "None recorded"}
  Reported reactions: ${r.reactions?.join(", ") || "None"}
  Key findings: ${r.key_findings?.join(", ") || "None"}
  Abnormal results: ${r.abnormal_results?.join(", ") || "None"}
  Notes: ${r.consultation_notes ?? "None"}`;
    })
    .join("\n\n");
}
