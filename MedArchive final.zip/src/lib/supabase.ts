import { createClient } from "@supabase/supabase-js";
import { projectId, publicAnonKey } from "../../utils/supabase/info";

// Use info.tsx values (auto-populated by Figma Make when Supabase is connected)
const supabaseUrl = `https://${projectId}.supabase.co`;
const supabaseAnonKey = publicAnonKey;

export const isSupabaseConfigured = Boolean(projectId) && Boolean(publicAnonKey);

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

export const STORAGE_BUCKET = "medical-documents";

// Edge function base URL — proxies Gemini calls server-side
export const EDGE_FN_URL = `${supabaseUrl}/functions/v1/server`;

export const MIGRATION_SQL = `-- Run this if you already created the table and need the new columns
ALTER TABLE medical_records
  ADD COLUMN IF NOT EXISTS diagnosis TEXT,
  ADD COLUMN IF NOT EXISTS summary TEXT,
  ADD COLUMN IF NOT EXISTS key_findings TEXT[] DEFAULT '{}',
  ADD COLUMN IF NOT EXISTS abnormal_results TEXT[] DEFAULT '{}';`;

export const SETUP_SQL = `-- Run this in your Supabase SQL Editor

-- Medical records table
CREATE TABLE IF NOT EXISTS medical_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users NOT NULL,
  consultation_date DATE,
  doctor_name TEXT,
  symptoms TEXT[] DEFAULT '{}',
  medicines JSONB DEFAULT '[]',
  reactions TEXT[] DEFAULT '{}',
  consultation_notes TEXT,
  diagnosis TEXT,
  summary TEXT,
  key_findings TEXT[] DEFAULT '{}',
  abnormal_results TEXT[] DEFAULT '{}',
  document_url TEXT,
  document_name TEXT,
  document_type TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE medical_records ENABLE ROW LEVEL SECURITY;

-- Policy: users can only access their own records
CREATE POLICY "Users own their records"
  ON medical_records FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- Storage bucket for medical documents (private)
INSERT INTO storage.buckets (id, name, public)
  VALUES ('medical-documents', 'medical-documents', false)
  ON CONFLICT (id) DO NOTHING;

-- Storage policies
CREATE POLICY "Users upload own docs" ON storage.objects
  FOR INSERT WITH CHECK (
    bucket_id = 'medical-documents'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users read own docs" ON storage.objects
  FOR SELECT USING (
    bucket_id = 'medical-documents'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );

CREATE POLICY "Users delete own docs" ON storage.objects
  FOR DELETE USING (
    bucket_id = 'medical-documents'
    AND auth.uid()::text = (storage.foldername(name))[1]
  );`;
