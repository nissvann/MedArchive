export interface Medicine {
  name: string;
  dosage: string;
  instructions: string;
  frequency?: string;
}

/** Returned by the summarize-report edge function */
export interface SummarizeResult {
  consultation_date: string | null;
  doctor_name: string | null;
  symptoms: string[];
  diagnosis: string | null;
  consultation_notes: string | null;
  medications: Medicine[];
  reactions: string[];
  summary: string | null;
  key_findings: string[];
  abnormal_results: string[];
}

/** The shape of a row in medical_records */
export interface MedicalRecord {
  id: string;
  user_id: string;
  consultation_date: string | null;
  doctor_name: string | null;
  symptoms: string[];
  medicines: Medicine[];        // stored as JSONB
  reactions: string[];
  consultation_notes: string | null;
  diagnosis: string | null;
  summary: string | null;
  key_findings: string[];
  abnormal_results: string[];
  document_url: string | null;  // storage path (e.g. "user-id/timestamp.jpg")
  document_name: string | null;
  document_type: string | null;
  created_at: string;
  updated_at: string;
}

/** The editable form state on the Review page */
export interface ReviewFormData {
  consultation_date: string | null;
  doctor_name: string | null;
  symptoms: string[];
  diagnosis: string | null;
  consultation_notes: string | null;
  medicines: Medicine[];
  reactions: string[];
  summary: string | null;
  key_findings: string[];
  abnormal_results: string[];
}

export const EMPTY_FORM: ReviewFormData = {
  consultation_date: null,
  doctor_name: null,
  symptoms: [],
  diagnosis: null,
  consultation_notes: null,
  medicines: [],
  reactions: [],
  summary: null,
  key_findings: [],
  abnormal_results: [],
};

/** Maps a SummarizeResult to ReviewFormData */
export function summarizeResultToForm(r: SummarizeResult): ReviewFormData {
  return {
    consultation_date: r.consultation_date ?? null,
    doctor_name: r.doctor_name ?? null,
    symptoms: Array.isArray(r.symptoms) ? r.symptoms : [],
    diagnosis: r.diagnosis ?? null,
    consultation_notes: r.consultation_notes ?? null,
    medicines: Array.isArray(r.medications) ? r.medications : [],
    reactions: Array.isArray(r.reactions) ? r.reactions : [],
    summary: r.summary ?? null,
    key_findings: Array.isArray(r.key_findings) ? r.key_findings : [],
    abnormal_results: Array.isArray(r.abnormal_results) ? r.abnormal_results : [],
  };
}
