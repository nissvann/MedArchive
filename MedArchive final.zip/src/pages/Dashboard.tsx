import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { supabase } from "../lib/supabase";
import type { MedicalRecord } from "../lib/types";
import { Upload, Clock, Search, MessageSquare, FileText, Calendar, Pill } from "lucide-react";
import Layout from "../components/Layout";

export default function Dashboard() {
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [userEmail, setUserEmail] = useState("");

  useEffect(() => {
    async function load() {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) setUserEmail(user.email ?? "");

      const { data } = await supabase
        .from("medical_records")
        .select("*")
        .order("consultation_date", { ascending: false })
        .limit(3);
      setRecords((data as MedicalRecord[]) ?? []);
      setLoading(false);
    }
    load();
  }, []);

  const totalMeds = records.reduce((acc, r) => acc + (r.medicines?.length ?? 0), 0);
  const lastConsult = records[0]?.consultation_date;

  const quickActions = [
    {
      to: "/upload",
      icon: Upload,
      label: "Upload document",
      desc: "Add a prescription or medical note",
      color: "var(--color-primary)",
      bg: "var(--color-secondary)",
    },
    {
      to: "/timeline",
      icon: Clock,
      label: "View timeline",
      desc: "See your full medical history",
      color: "#0891b2",
      bg: "#ecfeff",
    },
    {
      to: "/memory",
      icon: MessageSquare,
      label: "Ask Medical Memory",
      desc: "Questions from your saved records",
      color: "#7c3aed",
      bg: "#f5f3ff",
    },
    {
      to: "/search",
      icon: Search,
      label: "Search records",
      desc: "Find medicines, symptoms, doctors",
      color: "#d97706",
      bg: "#fffbeb",
    },
  ];

  const firstName = userEmail.split("@")[0];

  return (
    <Layout>
      <div className="space-y-8">
        {/* Header */}
        <div>
          <h1 className="text-2xl font-semibold mb-1" style={{ color: "var(--color-foreground)" }}>
            Hello, {firstName} 👋
          </h1>
          <p style={{ color: "var(--color-muted-foreground)" }}>
            Your personal medical timeline.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-4">
          {[
            {
              icon: FileText,
              label: "Consultations",
              value: loading ? "—" : records.length,
              color: "var(--color-primary)",
            },
            {
              icon: Calendar,
              label: "Last consultation",
              value: lastConsult
                ? new Date(lastConsult).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })
                : "None yet",
              color: "#0891b2",
            },
            {
              icon: Pill,
              label: "Medicines tracked",
              value: loading ? "—" : totalMeds,
              color: "#7c3aed",
            },
          ].map(({ icon: Icon, label, value, color }) => (
            <div
              key={label}
              className="rounded-2xl border p-5"
              style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}
            >
              <Icon size={18} style={{ color }} className="mb-3" />
              <p className="text-xs mb-1" style={{ color: "var(--color-muted-foreground)" }}>{label}</p>
              <p className="text-xl font-semibold" style={{ color: "var(--color-foreground)" }}>{value}</p>
            </div>
          ))}
        </div>

        {/* Quick actions */}
        <div>
          <h2 className="font-semibold mb-4" style={{ color: "var(--color-foreground)" }}>Quick actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {quickActions.map(({ to, icon: Icon, label, desc, color, bg }) => (
              <Link
                key={to}
                to={to}
                className="flex items-center gap-4 p-4 rounded-2xl border transition-all hover:shadow-sm hover:scale-[1.01]"
                style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}
              >
                <div className="w-10 h-10 rounded-xl flex items-center justify-center shrink-0" style={{ background: bg }}>
                  <Icon size={18} style={{ color }} />
                </div>
                <div>
                  <p className="font-medium text-sm" style={{ color: "var(--color-foreground)" }}>{label}</p>
                  <p className="text-xs" style={{ color: "var(--color-muted-foreground)" }}>{desc}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>

        {/* Recent records */}
        <div>
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-semibold" style={{ color: "var(--color-foreground)" }}>Recent consultations</h2>
            <Link
              to="/timeline"
              className="text-sm font-medium"
              style={{ color: "var(--color-primary)" }}
            >
              View all
            </Link>
          </div>

          {loading ? (
            <div className="space-y-3">
              {[1, 2].map((i) => (
                <div key={i} className="h-20 rounded-2xl animate-pulse" style={{ background: "var(--color-muted)" }} />
              ))}
            </div>
          ) : records.length === 0 ? (
            <div
              className="rounded-2xl border-2 border-dashed p-10 text-center"
              style={{ borderColor: "var(--color-border)" }}
            >
              <FileText size={32} className="mx-auto mb-3" style={{ color: "var(--color-muted-foreground)", opacity: 0.5 }} />
              <p className="font-medium mb-1" style={{ color: "var(--color-foreground)" }}>No records yet</p>
              <p className="text-sm mb-4" style={{ color: "var(--color-muted-foreground)" }}>
                Upload your first prescription to get started.
              </p>
              <Link
                to="/upload"
                className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium"
                style={{ background: "var(--color-primary)", color: "white" }}
              >
                <Upload size={14} />
                Upload document
              </Link>
            </div>
          ) : (
            <div className="space-y-3">
              {records.map((r) => (
                <div
                  key={r.id}
                  className="rounded-2xl border p-4"
                  style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        {r.consultation_date && (
                          <span className="text-sm font-medium" style={{ color: "var(--color-foreground)" }}>
                            {new Date(r.consultation_date).toLocaleDateString("en-GB", {
                              day: "numeric", month: "long", year: "numeric",
                            })}
                          </span>
                        )}
                        {r.doctor_name && (
                          <span className="text-xs px-2 py-0.5 rounded-full" style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}>
                            {r.doctor_name}
                          </span>
                        )}
                      </div>
                      {r.symptoms?.length > 0 && (
                        <p className="text-sm" style={{ color: "var(--color-muted-foreground)" }}>
                          Symptoms: {r.symptoms.join(", ")}
                        </p>
                      )}
                      {r.medicines?.length > 0 && (
                        <p className="text-sm mt-0.5" style={{ color: "var(--color-muted-foreground)" }}>
                          Medicines: {r.medicines.map((m) => m.name).join(", ")}
                        </p>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}
