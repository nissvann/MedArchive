import { Link } from "react-router-dom";
import {
  Shield,
  Eye,
  Lock,
  ArrowRight,
  FileText,
  Sparkles,
  CheckCircle,
  Clock,
  Heart,
} from "lucide-react";

const steps = [
  {
    icon: FileText,
    label: "Upload",
    desc: "Photo, scan, or PDF of your prescription or medical document.",
  },
  {
    icon: Sparkles,
    label: "AI Extracts",
    desc: "Gemini Vision reads medicines, symptoms, doctor, date, and notes.",
  },
  {
    icon: Eye,
    label: "You Review",
    desc: "Check every field. Edit anything. Nothing saves without your approval.",
  },
  {
    icon: Clock,
    label: "Timeline",
    desc: "Your verified records form a clear, searchable medical history.",
  },
];

const trustPoints = [
  {
    icon: Eye,
    title: "You verify everything",
    desc: "AI results are never saved automatically. You review and approve before anything enters your timeline.",
  },
  {
    icon: Sparkles,
    title: "AI never guesses",
    desc: "If information can't be clearly read from your document, we show \"Not detected\" — never a guess.",
  },
  {
    icon: Lock,
    title: "Your data is private",
    desc: "Documents are stored privately with Row Level Security. Only you can access your records.",
  },
  {
    icon: Shield,
    title: "Not an AI doctor",
    desc: "MedArchive organizes what you've been told. It never diagnoses, prescribes, or gives medical advice.",
  },
];

export default function Landing() {
  return (
    <div className="min-h-screen" style={{ background: "var(--color-background)" }}>
      {/* Nav */}
      <header className="border-b" style={{ borderColor: "var(--color-border)" }}>
        <div className="max-w-5xl mx-auto px-5 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span
              className="w-7 h-7 rounded-lg flex items-center justify-center"
              style={{ background: "var(--color-primary)" }}
            >
              <Heart size={14} color="white" fill="white" />
            </span>
            <span className="font-semibold text-sm tracking-tight">MedArchive</span>
          </div>
          <div className="flex items-center gap-3">
            <Link
              to="/auth"
              className="text-sm font-medium transition-colors"
              style={{ color: "var(--color-muted-foreground)" }}
            >
              Log in
            </Link>
            <Link
              to="/auth?mode=signup"
              className="text-sm font-medium px-4 py-2 rounded-lg transition-opacity hover:opacity-90"
              style={{ background: "var(--color-primary)", color: "white" }}
            >
              Get started
            </Link>
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="max-w-5xl mx-auto px-5 pt-20 pb-24 text-center animate-fade-in">
        <div
          className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1 rounded-full mb-6"
          style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}
        >
          <Shield size={11} />
          Personal medical memory — not an AI doctor
        </div>

        <h1
          className="display-font text-4xl sm:text-5xl lg:text-6xl leading-[1.1] mb-6 max-w-3xl mx-auto"
          style={{ color: "var(--color-foreground)" }}
        >
          Never forget what happened at your last consultation.
        </h1>

        <p
          className="text-lg sm:text-xl leading-relaxed max-w-2xl mx-auto mb-10"
          style={{ color: "var(--color-muted-foreground)" }}
        >
          Turn prescriptions and medical notes into a simple, personal timeline — so you can remember
          what you were prescribed, what symptoms you had, and what your doctor told you.
        </p>

        <Link
          to="/auth?mode=signup"
          className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-base font-medium transition-opacity hover:opacity-90"
          style={{ background: "var(--color-primary)", color: "white" }}
        >
          Create My Medical Timeline
          <ArrowRight size={16} />
        </Link>

        <p className="mt-4 text-xs" style={{ color: "var(--color-muted-foreground)" }}>
          Free to use. No credit card required.
        </p>
      </section>

      {/* How it works */}
      <section
        className="border-y py-20"
        style={{ borderColor: "var(--color-border)", background: "var(--color-muted)" }}
      >
        <div className="max-w-5xl mx-auto px-5">
          <div className="text-center mb-14">
            <h2
              className="display-font text-3xl sm:text-4xl mb-3"
              style={{ color: "var(--color-foreground)" }}
            >
              How it works
            </h2>
            <p style={{ color: "var(--color-muted-foreground)" }}>
              Four simple steps from document to memory.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {steps.map(({ icon: Icon, label, desc }, i) => (
              <div
                key={label}
                className="rounded-2xl p-6 border relative animate-slide-up"
                style={{
                  background: "var(--color-card)",
                  borderColor: "var(--color-border)",
                  animationDelay: `${i * 60}ms`,
                }}
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: "var(--color-secondary)" }}
                >
                  <Icon size={18} style={{ color: "var(--color-primary)" }} />
                </div>
                <div
                  className="text-xs font-semibold uppercase tracking-wider mb-1"
                  style={{ color: "var(--color-muted-foreground)" }}
                >
                  Step {i + 1}
                </div>
                <h3 className="font-semibold mb-2" style={{ color: "var(--color-foreground)" }}>
                  {label}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "var(--color-muted-foreground)" }}>
                  {desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Problem section */}
      <section className="py-20 max-w-5xl mx-auto px-5">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h2
              className="display-font text-3xl sm:text-4xl mb-5 leading-tight"
              style={{ color: "var(--color-foreground)" }}
            >
              Your medical history, finally in one place.
            </h2>
            <p className="text-base leading-relaxed mb-6" style={{ color: "var(--color-muted-foreground)" }}>
              How many times have you tried to remember which medicine you were prescribed six months ago?
              Or which symptoms you had before your last blood test?
            </p>
            <p className="text-base leading-relaxed" style={{ color: "var(--color-muted-foreground)" }}>
              MedArchive turns your prescriptions and medical documents into a searchable personal
              timeline — so you can answer those questions in seconds.
            </p>
          </div>

          <div className="space-y-3">
            {[
              "When did I last take this medicine?",
              "What symptoms did I have in March?",
              "Which medicine caused that reaction?",
              "What did my doctor say at my last visit?",
              "Am I still taking this prescription?",
            ].map((q) => (
              <div
                key={q}
                className="flex items-center gap-3 px-4 py-3 rounded-xl border"
                style={{ background: "var(--color-muted)", borderColor: "var(--color-border)" }}
              >
                <CheckCircle size={16} style={{ color: "var(--color-primary)" }} />
                <span className="text-sm" style={{ color: "var(--color-foreground)" }}>{q}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust section */}
      <section
        className="border-y py-20"
        style={{ borderColor: "var(--color-border)", background: "var(--color-muted)" }}
      >
        <div className="max-w-5xl mx-auto px-5">
          <div className="text-center mb-14">
            <h2
              className="display-font text-3xl sm:text-4xl mb-3"
              style={{ color: "var(--color-foreground)" }}
            >
              AI that organizes.{" "}
              <span style={{ color: "var(--color-primary)" }}>You stay in control.</span>
            </h2>
            <p className="max-w-xl mx-auto" style={{ color: "var(--color-muted-foreground)" }}>
              We built MedArchive around one principle: your medical information is too important to
              leave to an algorithm alone.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {trustPoints.map(({ icon: Icon, title, desc }) => (
              <div
                key={title}
                className="rounded-2xl p-6 border"
                style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}
              >
                <div
                  className="w-9 h-9 rounded-xl flex items-center justify-center mb-4"
                  style={{ background: "var(--color-secondary)" }}
                >
                  <Icon size={18} style={{ color: "var(--color-primary)" }} />
                </div>
                <h3 className="font-semibold mb-2" style={{ color: "var(--color-foreground)" }}>
                  {title}
                </h3>
                <p className="text-sm leading-relaxed" style={{ color: "var(--color-muted-foreground)" }}>
                  {desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 text-center">
        <div className="max-w-2xl mx-auto px-5">
          <h2
            className="display-font text-3xl sm:text-4xl mb-5"
            style={{ color: "var(--color-foreground)" }}
          >
            Your medical memory starts today.
          </h2>
          <p className="mb-8" style={{ color: "var(--color-muted-foreground)" }}>
            Upload your first prescription and see your information extracted, reviewed, and saved in
            minutes.
          </p>
          <Link
            to="/auth?mode=signup"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl text-base font-medium transition-opacity hover:opacity-90"
            style={{ background: "var(--color-primary)", color: "white" }}
          >
            Create My Medical Timeline
            <ArrowRight size={16} />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-8" style={{ borderColor: "var(--color-border)" }}>
        <div className="max-w-5xl mx-auto px-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span
              className="w-5 h-5 rounded flex items-center justify-center"
              style={{ background: "var(--color-primary)" }}
            >
              <Heart size={10} color="white" fill="white" />
            </span>
            <span className="text-sm font-medium">MedArchive</span>
          </div>
          <p className="text-xs text-center" style={{ color: "var(--color-muted-foreground)" }}>
            MedArchive organizes your records. Always consult a qualified medical professional for medical decisions.
          </p>
        </div>
      </footer>
    </div>
  );
}
