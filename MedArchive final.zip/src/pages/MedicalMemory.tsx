import { useEffect, useState, useRef } from "react";
import { supabase } from "../lib/supabase";
import { queryMedicalMemory, buildRecordsContext } from "../lib/gemini";
import type { MedicalRecord } from "../lib/types";
import Layout from "../components/Layout";
import { MessageSquare, Send, AlertCircle, Shield, Loader } from "lucide-react";

interface Message {
  role: "user" | "assistant";
  content: string;
}

const EXAMPLE_QUESTIONS = [
  "What did my doctor prescribe in my last consultation?",
  "When did I last have a sore throat?",
  "Which medicines have I been prescribed?",
  "Have I reported any reactions to medicine?",
  "What were my symptoms in my most recent visit?",
];

export default function MedicalMemory() {
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const [recordsLoading, setRecordsLoading] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from("medical_records")
        .select("*")
        .order("consultation_date", { ascending: false });
      setRecords((data as MedicalRecord[]) ?? []);
      setRecordsLoading(false);
    }
    load();
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend(question?: string) {
    const q = (question ?? input).trim();
    if (!q || loading) return;

    setInput("");
    const userMsg: Message = { role: "user", content: q };
    setMessages((prev) => [...prev, userMsg]);
    setLoading(true);

    try {
      const context = buildRecordsContext(records);
      const answer = await queryMedicalMemory(q, context);
      setMessages((prev) => [...prev, { role: "assistant", content: answer }]);
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Something went wrong.";
      setMessages((prev) => [
        ...prev,
        { role: "assistant", content: `Error: ${msg}` },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-4 flex flex-col" style={{ minHeight: "calc(100vh - 120px)" }}>
        {/* Header */}
        <div>
          <h1 className="text-2xl font-semibold mb-1" style={{ color: "var(--color-foreground)" }}>
            Medical Memory
          </h1>
          <p style={{ color: "var(--color-muted-foreground)" }}>
            Ask questions about your saved medical records.
          </p>
        </div>

        {/* Safety disclaimer */}
        <div
          className="flex items-start gap-2 p-4 rounded-xl text-sm"
          style={{ background: "#f0fdf4", color: "#166534", border: "1px solid #bbf7d0" }}
        >
          <Shield size={15} className="shrink-0 mt-0.5" />
          <div>
            <strong>Important: </strong>
            Medical Memory only answers from your verified saved records. It never diagnoses, prescribes,
            or gives medical advice. Always consult a qualified medical professional for health decisions.
          </div>
        </div>

        {!recordsLoading && records.length === 0 && (
          <div
            className="flex items-start gap-2 p-3 rounded-xl text-sm"
            style={{ background: "var(--color-muted)", color: "var(--color-muted-foreground)" }}
          >
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            No records saved yet. Upload and save documents first to use Medical Memory.
          </div>
        )}

        {/* Records summary */}
        {!recordsLoading && records.length > 0 && (
          <p className="text-xs" style={{ color: "var(--color-muted-foreground)" }}>
            Answering from <strong>{records.length}</strong> saved consultation{records.length !== 1 ? "s" : ""}.
          </p>
        )}

        {/* Chat messages */}
        <div className="flex-1 space-y-4">
          {messages.length === 0 && (
            <div className="space-y-3">
              <p className="text-sm font-medium" style={{ color: "var(--color-muted-foreground)" }}>
                Try asking:
              </p>
              <div className="grid gap-2">
                {EXAMPLE_QUESTIONS.map((q) => (
                  <button
                    key={q}
                    onClick={() => handleSend(q)}
                    disabled={loading || records.length === 0}
                    className="text-left px-4 py-3 rounded-xl border text-sm transition-colors hover:border-teal-300 disabled:opacity-50"
                    style={{
                      borderColor: "var(--color-border)",
                      background: "var(--color-card)",
                      color: "var(--color-foreground)",
                    }}
                  >
                    {q}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((msg, i) => (
            <div
              key={i}
              className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"} animate-slide-up`}
            >
              {msg.role === "assistant" && (
                <div
                  className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 mr-2 mt-0.5"
                  style={{ background: "var(--color-secondary)" }}
                >
                  <MessageSquare size={13} style={{ color: "var(--color-primary)" }} />
                </div>
              )}
              <div
                className="max-w-[80%] px-4 py-3 rounded-2xl text-sm leading-relaxed"
                style={
                  msg.role === "user"
                    ? { background: "var(--color-primary)", color: "white", borderBottomRightRadius: "4px" }
                    : { background: "var(--color-muted)", color: "var(--color-foreground)", borderBottomLeftRadius: "4px" }
                }
              >
                {msg.content}
              </div>
            </div>
          ))}

          {loading && (
            <div className="flex justify-start animate-slide-up">
              <div
                className="w-7 h-7 rounded-full flex items-center justify-center shrink-0 mr-2"
                style={{ background: "var(--color-secondary)" }}
              >
                <MessageSquare size={13} style={{ color: "var(--color-primary)" }} />
              </div>
              <div
                className="px-4 py-3 rounded-2xl flex items-center gap-2"
                style={{ background: "var(--color-muted)" }}
              >
                <Loader size={14} className="animate-spin" style={{ color: "var(--color-primary)" }} />
                <span className="text-sm" style={{ color: "var(--color-muted-foreground)" }}>
                  Searching your records...
                </span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input */}
        <div
          className="sticky bottom-4 rounded-2xl border p-3 flex gap-2"
          style={{
            background: "var(--color-card)",
            borderColor: "var(--color-border)",
            boxShadow: "0 4px 24px rgba(0,0,0,0.08)",
          }}
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleSend()}
            placeholder={
              records.length === 0
                ? "No records saved yet..."
                : "Ask about your medical history..."
            }
            disabled={loading || records.length === 0}
            className="flex-1 px-3 py-2 rounded-xl text-sm outline-none"
            style={{
              background: "var(--color-muted)",
              color: "var(--color-foreground)",
            }}
          />
          <button
            onClick={() => handleSend()}
            disabled={!input.trim() || loading || records.length === 0}
            className="w-9 h-9 rounded-xl flex items-center justify-center transition-opacity hover:opacity-80 disabled:opacity-40"
            style={{ background: "var(--color-primary)" }}
          >
            <Send size={15} color="white" />
          </button>
        </div>

        <p className="text-xs text-center pb-2" style={{ color: "var(--color-muted-foreground)" }}>
          Answers are based only on your verified saved records. This is not medical advice.
        </p>
      </div>
    </Layout>
  );
}
