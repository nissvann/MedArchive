import { useState } from "react";
import { useLocation, useNavigate, Link } from "react-router-dom";
import { supabase } from "../lib/supabase";
import type { Medicine, ReviewFormData, SummarizeResult } from "../lib/types";
import { EMPTY_FORM, summarizeResultToForm } from "../lib/types";
import Layout from "../components/Layout";
import {
  CheckCircle,
  Plus,
  X,
  AlertCircle,
  Info,
  Save,
  Sparkles,
  FileText,
} from "lucide-react";

interface LocationState {
  recordId: string;
  extractedData: SummarizeResult | null;
  extractionError: string | null;
  documentName: string;
  documentType: string;
  storagePath: string;
}

// ── Sub-components ────────────────────────────────────────────────────────────

function TagInput({
  label,
  values,
  onChange,
  placeholder,
  color,
}: {
  label: string;
  values: string[];
  onChange: (v: string[]) => void;
  placeholder: string;
  color?: string;
}) {
  const [input, setInput] = useState("");

  function add() {
    const trimmed = input.trim();
    if (trimmed && !values.includes(trimmed)) onChange([...values, trimmed]);
    setInput("");
  }

  return (
    <div>
      <label
        className="block text-sm font-medium mb-2"
        style={{ color: "var(--color-foreground)" }}
      >
        {label}
      </label>
      <div className="flex flex-wrap gap-1.5 mb-2 min-h-[1.5rem]">
        {values.map((v) => (
          <span
            key={v}
            className="tag"
            style={{
              background: color ?? "var(--color-secondary)",
              color: color ? "white" : "var(--color-secondary-foreground)",
            }}
          >
            {v}
            <button
              onClick={() => onChange(values.filter((x) => x !== v))}
              className="ml-1 opacity-70 hover:opacity-100"
            >
              <X size={11} />
            </button>
          </span>
        ))}
        {values.length === 0 && (
          <span className="text-xs" style={{ color: "var(--color-muted-foreground)" }}>
            Not detected — add if applicable
          </span>
        )}
      </div>
      <div className="flex gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter") {
              e.preventDefault();
              add();
            }
          }}
          placeholder={placeholder}
          className="flex-1 px-3 py-2 rounded-xl border text-sm outline-none"
          style={{
            borderColor: "var(--color-border)",
            background: "var(--color-background)",
            color: "var(--color-foreground)",
          }}
        />
        <button
          onClick={add}
          className="px-3 py-2 rounded-xl text-sm"
          style={{
            background: "var(--color-secondary)",
            color: "var(--color-secondary-foreground)",
          }}
        >
          <Plus size={14} />
        </button>
      </div>
    </div>
  );
}

function MedicineEditor({
  medicines,
  onChange,
}: {
  medicines: Medicine[];
  onChange: (m: Medicine[]) => void;
}) {
  function update(i: number, field: keyof Medicine, value: string) {
    onChange(medicines.map((m, idx) => (idx === i ? { ...m, [field]: value } : m)));
  }

  function add() {
    onChange([...medicines, { name: "", dosage: "", instructions: "", frequency: "" }]);
  }

  return (
    <div>
      <label
        className="block text-sm font-medium mb-2"
        style={{ color: "var(--color-foreground)" }}
      >
        Medicines / Medications
      </label>
      {medicines.length === 0 && (
        <p className="text-xs mb-2" style={{ color: "var(--color-muted-foreground)" }}>
          Not detected — add if applicable
        </p>
      )}
      <div className="space-y-3">
        {medicines.map((m, i) => (
          <div
            key={i}
            className="p-4 rounded-xl border relative"
            style={{ borderColor: "var(--color-border)", background: "var(--color-muted)" }}
          >
            <button
              onClick={() => onChange(medicines.filter((_, idx) => idx !== i))}
              className="absolute top-3 right-3 opacity-40 hover:opacity-100 transition-opacity"
            >
              <X size={14} />
            </button>
            <div className="grid grid-cols-2 gap-3">
              {(
                [
                  { field: "name" as const, label: "Medicine name", placeholder: "e.g. Amoxicillin" },
                  { field: "dosage" as const, label: "Dosage", placeholder: "e.g. 500 mg" },
                  { field: "instructions" as const, label: "Instructions", placeholder: "e.g. Take with food" },
                  { field: "frequency" as const, label: "Frequency", placeholder: "e.g. 3 times daily" },
                ]
              ).map(({ field, label, placeholder }) => (
                <div key={field}>
                  <p
                    className="text-xs font-medium mb-1"
                    style={{ color: "var(--color-muted-foreground)" }}
                  >
                    {label}
                  </p>
                  <input
                    value={m[field] ?? ""}
                    onChange={(e) => update(i, field, e.target.value)}
                    placeholder={placeholder}
                    className="w-full px-3 py-2 rounded-lg border text-sm outline-none"
                    style={{
                      borderColor: "var(--color-border)",
                      background: "var(--color-background)",
                      color: "var(--color-foreground)",
                    }}
                  />
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
      <button
        onClick={add}
        className="mt-3 flex items-center gap-1.5 text-sm font-medium"
        style={{ color: "var(--color-primary)" }}
      >
        <Plus size={14} /> Add medicine
      </button>
    </div>
  );
}

function TextField({
  label,
  value,
  onChange,
  placeholder,
  multiline = false,
}: {
  label: string;
  value: string | null;
  onChange: (v: string | null) => void;
  placeholder: string;
  multiline?: boolean;
}) {
  const sharedStyle = {
    borderColor: "var(--color-border)",
    background: "var(--color-background)",
    color: "var(--color-foreground)",
  };
  return (
    <div>
      <label
        className="block text-sm font-medium mb-1.5"
        style={{ color: "var(--color-foreground)" }}
      >
        {label}
      </label>
      {multiline ? (
        <textarea
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value || null)}
          placeholder={placeholder}
          rows={4}
          className="w-full px-3 py-2.5 rounded-xl border text-sm outline-none resize-none leading-relaxed"
          style={sharedStyle}
        />
      ) : (
        <input
          type="text"
          value={value ?? ""}
          onChange={(e) => onChange(e.target.value || null)}
          placeholder={placeholder}
          className="w-full px-3 py-2.5 rounded-xl border text-sm outline-none"
          style={sharedStyle}
        />
      )}
    </div>
  );
}

// ── Main page ─────────────────────────────────────────────────────────────────

export default function Review() {
  const location = useLocation();
  const navigate = useNavigate();
  const state = location.state as LocationState | undefined;

  const initialForm: ReviewFormData = state?.extractedData
    ? summarizeResultToForm(state.extractedData)
    : EMPTY_FORM;

  const [form, setForm] = useState<ReviewFormData>(initialForm);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);

  // Guard: no state means user navigated here directly
  if (!state?.recordId) {
    return (
      <Layout>
        <div className="max-w-xl mx-auto text-center py-20 space-y-4">
          <FileText
            size={40}
            className="mx-auto opacity-30"
            style={{ color: "var(--color-muted-foreground)" }}
          />
          <p style={{ color: "var(--color-muted-foreground)" }}>
            No document to review. Upload a document first.
          </p>
          <Link
            to="/upload"
            className="inline-flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium"
            style={{ background: "var(--color-primary)", color: "white" }}
          >
            Upload document
          </Link>
        </div>
      </Layout>
    );
  }

  const { recordId, extractionError, documentName } = state;
  const aiExtracted = Boolean(state.extractedData);

  async function handleSave() {
    setSaveError(null);
    setSaving(true);
    try {
      const { error: updateErr } = await supabase
        .from("medical_records")
        .update({
          consultation_date: form.consultation_date || null,
          doctor_name: form.doctor_name || null,
          symptoms: form.symptoms,
          diagnosis: form.diagnosis || null,
          consultation_notes: form.consultation_notes || null,
          medicines: form.medicines,
          reactions: form.reactions,
          summary: form.summary || null,
          key_findings: form.key_findings,
          abnormal_results: form.abnormal_results,
          updated_at: new Date().toISOString(),
        })
        .eq("id", recordId);

      if (updateErr) throw updateErr;
      navigate("/timeline", { state: { saved: true } });
    } catch (err: unknown) {
      setSaveError(err instanceof Error ? err.message : "Failed to save record.");
    } finally {
      setSaving(false);
    }
  }

  function patch<K extends keyof ReviewFormData>(key: K, value: ReviewFormData[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        {/* ── Header ── */}
        <div>
          <h1
            className="text-2xl font-semibold mb-1"
            style={{ color: "var(--color-foreground)" }}
          >
            Review what we found
          </h1>
          <p style={{ color: "var(--color-muted-foreground)" }}>
            {aiExtracted
              ? "Check every field carefully. Edit anything that's wrong. Nothing is final until you click Save."
              : "Fill in the details from your document. Nothing saves until you approve."}
          </p>
        </div>

        {/* ── AI success banner ── */}
        {aiExtracted && (
          <div
            className="flex items-start gap-2 p-4 rounded-xl text-sm"
            style={{
              background: "var(--color-secondary)",
              color: "var(--color-secondary-foreground)",
              border: "1px solid #99f6e4",
            }}
          >
            <Sparkles size={15} className="shrink-0 mt-0.5" />
            <span>
              AI extracted the information below from your document. Fields showing{" "}
              <strong>"Not detected"</strong> mean the information wasn't clearly readable — nothing
              was guessed.
            </span>
          </div>
        )}

        {/* ── Extraction error (real message from edge function) ── */}
        {extractionError && (
          <div
            className="flex items-start gap-2 p-4 rounded-xl text-sm"
            style={{ background: "#fef2f2", color: "#dc2626", border: "1px solid #fecaca" }}
          >
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            <div>
              <strong className="block mb-0.5">AI extraction failed</strong>
              <span className="font-mono text-xs break-all">{extractionError}</span>
              <p className="mt-2 text-xs" style={{ color: "#b91c1c" }}>
                Your document was saved to Storage. Please fill in the details manually below.
              </p>
            </div>
          </div>
        )}

        {/* ── No extraction, no error ── */}
        {!aiExtracted && !extractionError && (
          <div
            className="flex items-start gap-2 p-4 rounded-xl text-sm"
            style={{ background: "#fffbeb", color: "#92400e", border: "1px solid #fde68a" }}
          >
            <Info size={15} className="shrink-0 mt-0.5" />
            AI extraction was skipped. Fill in the details manually from your document.
          </div>
        )}

        {/* ── Save error ── */}
        {saveError && (
          <div
            className="flex items-start gap-2 p-3 rounded-xl text-sm"
            style={{ background: "#fef2f2", color: "#dc2626", border: "1px solid #fecaca" }}
          >
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            {saveError}
          </div>
        )}

        {/* ── Document reference ── */}
        {documentName && (
          <div
            className="flex items-center gap-2 px-4 py-3 rounded-xl text-sm"
            style={{ background: "var(--color-muted)", color: "var(--color-muted-foreground)" }}
          >
            <CheckCircle size={14} style={{ color: "var(--color-primary)" }} />
            Document:{" "}
            <strong style={{ color: "var(--color-foreground)" }}>{documentName}</strong>
          </div>
        )}

        {/* ── AI summary (read-only, collapsible) ── */}
        {form.summary && (
          <div
            className="px-4 py-3 rounded-xl text-sm leading-relaxed"
            style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}
          >
            <span className="font-medium">AI summary: </span>
            {form.summary}
          </div>
        )}

        {/* ── Editable form ── */}
        <div
          className="rounded-2xl border p-6 space-y-6"
          style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}
        >
          {/* Date */}
          <div>
            <label
              className="block text-sm font-medium mb-1.5"
              style={{ color: "var(--color-foreground)" }}
            >
              Consultation date
            </label>
            <input
              type="date"
              value={form.consultation_date ?? ""}
              onChange={(e) => patch("consultation_date", e.target.value || null)}
              className="px-3 py-2.5 rounded-xl border text-sm outline-none"
              style={{
                borderColor: "var(--color-border)",
                background: "var(--color-background)",
                color: "var(--color-foreground)",
              }}
            />
            {!form.consultation_date && (
              <p className="text-xs mt-1" style={{ color: "var(--color-muted-foreground)" }}>
                Not detected
              </p>
            )}
          </div>

          {/* Doctor */}
          <TextField
            label="Doctor / Practitioner"
            value={form.doctor_name}
            onChange={(v) => patch("doctor_name", v)}
            placeholder="Not detected"
          />

          {/* Diagnosis */}
          <TextField
            label="Diagnosis / Clinical impression"
            value={form.diagnosis}
            onChange={(v) => patch("diagnosis", v)}
            placeholder="Not detected"
          />

          {/* Symptoms */}
          <TagInput
            label="Symptoms"
            values={form.symptoms ?? []}
            onChange={(v) => patch("symptoms", v)}
            placeholder="Add symptom, press Enter"
          />

          {/* Key findings */}
          <TagInput
            label="Key findings"
            values={form.key_findings ?? []}
            onChange={(v) => patch("key_findings", v)}
            placeholder="e.g. BP 145/92, add finding, press Enter"
          />

          {/* Abnormal results */}
          <TagInput
            label="Abnormal results"
            values={form.abnormal_results ?? []}
            onChange={(v) => patch("abnormal_results", v)}
            placeholder="e.g. Elevated CRP, press Enter"
            color="#dc2626"
          />

          {/* Medicines */}
          <MedicineEditor
            medicines={form.medicines ?? []}
            onChange={(m) => patch("medicines", m)}
          />

          {/* Reported reactions */}
          <div>
            <TagInput
              label="Reported reactions"
              values={form.reactions ?? []}
              onChange={(v) => patch("reactions", v)}
              placeholder="Add reaction, press Enter"
            />
            <p className="text-xs mt-1.5" style={{ color: "var(--color-muted-foreground)" }}>
              Only add reactions explicitly mentioned in your document.
            </p>
          </div>

          {/* Consultation notes */}
          <TextField
            label="Consultation notes"
            value={form.consultation_notes}
            onChange={(v) => patch("consultation_notes", v)}
            placeholder="Not detected — add any clinical notes, advice, or follow-up instructions."
            multiline
          />
        </div>

        {/* ── Reactions disclaimer ── */}
        <div
          className="flex items-start gap-2 p-4 rounded-xl text-xs"
          style={{ background: "#fffbeb", color: "#92400e", border: "1px solid #fde68a" }}
        >
          <AlertCircle size={13} className="shrink-0 mt-0.5" />
          Reactions are listed as <strong>"Reported reactions"</strong> unless your document
          explicitly confirms a diagnosed allergy. MedArchive does not assess severity or confirm
          diagnoses.
        </div>

        {/* ── Actions ── */}
        <div className="flex gap-3 pb-4">
          <button
            onClick={() => navigate("/upload")}
            className="px-4 py-3 rounded-xl text-sm font-medium border transition-colors hover:bg-slate-50"
            style={{ borderColor: "var(--color-border)", color: "var(--color-muted-foreground)" }}
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-opacity hover:opacity-90 disabled:opacity-60"
            style={{ background: "var(--color-primary)", color: "white" }}
          >
            {saving ? (
              <>
                <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                Saving…
              </>
            ) : (
              <>
                <Save size={16} />
                Save to Timeline
              </>
            )}
          </button>
        </div>
      </div>
    </Layout>
  );
}
