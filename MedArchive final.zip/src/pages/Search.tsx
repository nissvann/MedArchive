import { useEffect, useState, useMemo } from "react";
import { supabase } from "../lib/supabase";
import type { MedicalRecord } from "../lib/types";
import Layout from "../components/Layout";
import { Search as SearchIcon, Pill, User, AlertTriangle, Calendar, X } from "lucide-react";
import { Link } from "react-router-dom";

type FilterType = "all" | "medicine" | "symptom" | "doctor" | "reaction";

const FILTER_OPTIONS: { value: FilterType; label: string; icon: React.ElementType }[] = [
  { value: "all", label: "All", icon: SearchIcon },
  { value: "medicine", label: "Medicines", icon: Pill },
  { value: "symptom", label: "Symptoms", icon: AlertTriangle },
  { value: "doctor", label: "Doctors", icon: User },
  { value: "reaction", label: "Reactions", icon: AlertTriangle },
];

function highlight(text: string, query: string) {
  if (!query.trim()) return text;
  const regex = new RegExp(`(${query.trim().replace(/[.*+?^${}()|[\]\\]/g, "\\$&")})`, "gi");
  const parts = text.split(regex);
  return parts.map((part, i) =>
    regex.test(part) ? (
      <mark key={i} style={{ background: "#99f6e4", color: "inherit", borderRadius: "2px" }}>{part}</mark>
    ) : part
  );
}

function matchesQuery(record: MedicalRecord, query: string, filter: FilterType): boolean {
  const q = query.toLowerCase().trim();
  if (!q) return true;

  if (filter === "medicine" || filter === "all") {
    if (record.medicines?.some((m) => m.name.toLowerCase().includes(q) || m.dosage?.toLowerCase().includes(q)))
      return true;
  }
  if (filter === "symptom" || filter === "all") {
    if (record.symptoms?.some((s) => s.toLowerCase().includes(q))) return true;
  }
  if (filter === "doctor" || filter === "all") {
    if (record.doctor_name?.toLowerCase().includes(q)) return true;
  }
  if (filter === "reaction" || filter === "all") {
    if (record.reactions?.some((r) => r.toLowerCase().includes(q))) return true;
  }
  if (filter === "all") {
    if (record.consultation_notes?.toLowerCase().includes(q)) return true;
    if (record.consultation_date?.includes(q)) return true;
  }
  return false;
}

export default function Search() {
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<FilterType>("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from("medical_records")
        .select("*")
        .order("consultation_date", { ascending: false });
      setRecords((data as MedicalRecord[]) ?? []);
      setLoading(false);
    }
    load();
  }, []);

  const results = useMemo(() => {
    return records.filter((r) => {
      const matchQ = matchesQuery(r, query, filter);
      const matchFrom = !dateFrom || (r.consultation_date && r.consultation_date >= dateFrom);
      const matchTo = !dateTo || (r.consultation_date && r.consultation_date <= dateTo);
      return matchQ && matchFrom && matchTo;
    });
  }, [records, query, filter, dateFrom, dateTo]);

  function clearFilters() {
    setQuery("");
    setFilter("all");
    setDateFrom("");
    setDateTo("");
  }

  const hasFilters = query || filter !== "all" || dateFrom || dateTo;

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div>
          <h1 className="text-2xl font-semibold mb-1" style={{ color: "var(--color-foreground)" }}>
            Search records
          </h1>
          <p style={{ color: "var(--color-muted-foreground)" }}>
            Find medicines, symptoms, doctors, reactions, and dates.
          </p>
        </div>

        {/* Search input */}
        <div className="relative">
          <SearchIcon
            size={16}
            className="absolute left-3.5 top-1/2 -translate-y-1/2"
            style={{ color: "var(--color-muted-foreground)" }}
          />
          <input
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search medicines, symptoms, doctors..."
            className="w-full pl-10 pr-4 py-3 rounded-xl border text-sm outline-none"
            style={{
              borderColor: "var(--color-border)",
              background: "var(--color-background)",
              color: "var(--color-foreground)",
            }}
          />
          {query && (
            <button
              onClick={() => setQuery("")}
              className="absolute right-3 top-1/2 -translate-y-1/2"
              style={{ color: "var(--color-muted-foreground)" }}
            >
              <X size={15} />
            </button>
          )}
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-2">
          {FILTER_OPTIONS.map(({ value, label, icon: Icon }) => (
            <button
              key={value}
              onClick={() => setFilter(value)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-sm font-medium transition-colors"
              style={{
                background: filter === value ? "var(--color-primary)" : "var(--color-muted)",
                color: filter === value ? "white" : "var(--color-muted-foreground)",
              }}
            >
              <Icon size={13} />
              {label}
            </button>
          ))}
        </div>

        {/* Date range */}
        <div className="flex gap-3 items-center">
          <Calendar size={14} style={{ color: "var(--color-muted-foreground)" }} />
          <input
            type="date"
            value={dateFrom}
            onChange={(e) => setDateFrom(e.target.value)}
            className="px-3 py-2 rounded-xl border text-sm outline-none"
            style={{ borderColor: "var(--color-border)", background: "var(--color-background)", color: "var(--color-foreground)" }}
          />
          <span className="text-sm" style={{ color: "var(--color-muted-foreground)" }}>to</span>
          <input
            type="date"
            value={dateTo}
            onChange={(e) => setDateTo(e.target.value)}
            className="px-3 py-2 rounded-xl border text-sm outline-none"
            style={{ borderColor: "var(--color-border)", background: "var(--color-background)", color: "var(--color-foreground)" }}
          />
          {hasFilters && (
            <button
              onClick={clearFilters}
              className="flex items-center gap-1 text-sm"
              style={{ color: "var(--color-muted-foreground)" }}
            >
              <X size={13} /> Clear
            </button>
          )}
        </div>

        {/* Results */}
        {loading ? (
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-24 rounded-2xl animate-pulse" style={{ background: "var(--color-muted)" }} />
            ))}
          </div>
        ) : records.length === 0 ? (
          <div className="text-center py-12">
            <p className="mb-2" style={{ color: "var(--color-muted-foreground)" }}>No records saved yet.</p>
            <Link to="/upload" className="text-sm font-medium" style={{ color: "var(--color-primary)" }}>
              Upload your first document
            </Link>
          </div>
        ) : results.length === 0 ? (
          <div className="text-center py-12">
            <p style={{ color: "var(--color-muted-foreground)" }}>
              No records match your search.
            </p>
          </div>
        ) : (
          <>
            <p className="text-sm" style={{ color: "var(--color-muted-foreground)" }}>
              {results.length} result{results.length !== 1 ? "s" : ""}
            </p>
            <div className="space-y-4">
              {results.map((r) => (
                <div
                  key={r.id}
                  className="rounded-2xl border p-5"
                  style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}
                >
                  <div className="flex items-center gap-2 flex-wrap mb-3">
                    {r.consultation_date && (
                      <span className="text-sm font-semibold" style={{ color: "var(--color-foreground)" }}>
                        {new Date(r.consultation_date + "T12:00:00").toLocaleDateString("en-GB", {
                          day: "numeric", month: "long", year: "numeric",
                        })}
                      </span>
                    )}
                    {r.doctor_name && (
                      <span
                        className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
                        style={{ background: "var(--color-muted)", color: "var(--color-muted-foreground)" }}
                      >
                        <User size={10} />
                        {highlight(r.doctor_name, query)}
                      </span>
                    )}
                  </div>

                  <div className="space-y-2">
                    {r.symptoms?.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {r.symptoms.map((s) => (
                          <span key={s} className="tag" style={{ background: "#fef3c7", color: "#92400e" }}>
                            {highlight(s, query)}
                          </span>
                        ))}
                      </div>
                    )}
                    {r.medicines?.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {r.medicines.map((m) => (
                          <span key={m.name} className="tag flex items-center gap-1" style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}>
                            <Pill size={10} />
                            {highlight(m.name, query)}
                            {m.dosage && <span className="opacity-70">· {highlight(m.dosage, query)}</span>}
                          </span>
                        ))}
                      </div>
                    )}
                    {r.reactions?.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {r.reactions.map((rx) => (
                          <span key={rx} className="tag" style={{ background: "#fef2f2", color: "#dc2626" }}>
                            <AlertTriangle size={10} />
                            {highlight(rx, query)}
                          </span>
                        ))}
                      </div>
                    )}
                    {r.consultation_notes && query && r.consultation_notes.toLowerCase().includes(query.toLowerCase()) && (
                      <p className="text-sm mt-1 line-clamp-2" style={{ color: "var(--color-muted-foreground)" }}>
                        {highlight(r.consultation_notes, query)}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </Layout>
  );
}
