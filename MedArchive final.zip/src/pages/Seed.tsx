import { useState } from "react";
import { Link } from "react-router-dom";
import { EDGE_FN_URL } from "../lib/supabase";
import { Heart, Database, CheckCircle, AlertCircle, Loader, ArrowRight } from "lucide-react";

const SAMPLE_PREVIEW = [
  { date: "12 Mar 2024", doctor: "Dr. Sarah Mitchell", summary: "Bacterial tonsillitis — Amoxicillin, Paracetamol, Difflam" },
  { date: "4 Jun 2024", doctor: "Dr. James Okafor", summary: "Elevated blood pressure — Amlodipine 5mg, Vitamin D3" },
  { date: "19 Aug 2024", doctor: "Dr. Sarah Mitchell", summary: "Reported reaction: skin rash following Amoxicillin course" },
  { date: "22 Oct 2024", doctor: "Dr. James Okafor", summary: "BP review — continued Amlodipine, added Magnesium" },
  { date: "8 Jan 2025", doctor: "Dr. Priya Sharma", summary: "Viral gastroenteritis — Dioralyte, Loperamide, Domperidone" },
  { date: "14 Apr 2025", doctor: "Dr. James Okafor", summary: "Lower back pain — Ibuprofen, Omeprazole; BP excellent" },
];

export default function Seed() {
  const [status, setStatus] = useState<"idle" | "loading" | "done" | "error">("idle");
  const [message, setMessage] = useState("");
  const [count, setCount] = useState(0);

  async function handleSeed() {
    setStatus("loading");
    try {
      const res = await fetch(`${EDGE_FN_URL}/make-server-7c00bccb/seed`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
      });
      const json = await res.json();
      if (!res.ok) throw new Error(json.error ?? "Seed failed");
      setCount(json.seeded);
      setStatus("done");
    } catch (err: unknown) {
      setMessage(err instanceof Error ? err.message : "Unknown error");
      setStatus("error");
    }
  }

  return (
    <div
      className="min-h-screen flex items-center justify-center p-6"
      style={{ background: "var(--color-muted)" }}
    >
      <div className="max-w-lg w-full space-y-6 animate-fade-in">
        {/* Logo */}
        <div className="flex items-center gap-2">
          <span className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: "var(--color-primary)" }}>
            <Heart size={14} color="white" fill="white" />
          </span>
          <span className="font-semibold text-sm">MedArchive</span>
          <span
            className="text-xs px-2 py-0.5 rounded-full font-medium ml-1"
            style={{ background: "#fef3c7", color: "#92400e" }}
          >
            Demo Seeder
          </span>
        </div>

        <div className="rounded-2xl border p-6 space-y-5" style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}>
          <div className="flex items-start gap-3">
            <div className="w-9 h-9 rounded-xl flex items-center justify-center shrink-0" style={{ background: "var(--color-secondary)" }}>
              <Database size={18} style={{ color: "var(--color-primary)" }} />
            </div>
            <div>
              <h1 className="font-semibold text-lg" style={{ color: "var(--color-foreground)" }}>
                Load sample medical records
              </h1>
              <p className="text-sm mt-0.5" style={{ color: "var(--color-muted-foreground)" }}>
                Seeds 6 realistic consultations spanning 13 months for the demo user.
              </p>
            </div>
          </div>

          {/* Preview */}
          <div className="space-y-2">
            {SAMPLE_PREVIEW.map(({ date, doctor, summary }) => (
              <div
                key={date}
                className="flex items-start gap-3 px-3 py-2.5 rounded-xl"
                style={{ background: "var(--color-muted)" }}
              >
                <div className="text-right shrink-0 w-20">
                  <p className="text-xs font-semibold" style={{ color: "var(--color-primary)" }}>{date}</p>
                  <p className="text-xs" style={{ color: "var(--color-muted-foreground)" }}>{doctor}</p>
                </div>
                <p className="text-xs leading-relaxed" style={{ color: "var(--color-foreground)" }}>{summary}</p>
              </div>
            ))}
          </div>

          {/* Status */}
          {status === "done" && (
            <div
              className="flex items-center gap-2 p-3 rounded-xl text-sm"
              style={{ background: "#f0fdf4", color: "#166534" }}
            >
              <CheckCircle size={15} />
              {count} records seeded successfully. The demo user's timeline is ready.
            </div>
          )}
          {status === "error" && (
            <div
              className="flex items-start gap-2 p-3 rounded-xl text-sm"
              style={{ background: "#fef2f2", color: "#dc2626" }}
            >
              <AlertCircle size={15} className="shrink-0 mt-0.5" />
              {message || "Seed failed. Make sure the edge function is deployed and SUPABASE_SERVICE_ROLE_KEY is set."}
            </div>
          )}

          {/* Actions */}
          <div className="flex gap-3">
            {status !== "done" ? (
              <button
                onClick={handleSeed}
                disabled={status === "loading"}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-opacity hover:opacity-90 disabled:opacity-60"
                style={{ background: "var(--color-primary)", color: "white" }}
              >
                {status === "loading" ? (
                  <><Loader size={15} className="animate-spin" /> Seeding...</>
                ) : (
                  <><Database size={15} /> Seed {SAMPLE_PREVIEW.length} records</>
                )}
              </button>
            ) : (
              <Link
                to="/timeline"
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium"
                style={{ background: "var(--color-primary)", color: "white" }}
              >
                View timeline <ArrowRight size={15} />
              </Link>
            )}
          </div>
        </div>

        <p className="text-xs text-center" style={{ color: "var(--color-muted-foreground)" }}>
          This page seeds data for user ID <code className="bg-slate-200 px-1 rounded text-xs">ee88e5c7-ef50-49c6-a460-8b48caf0f11b</code>
        </p>
      </div>
    </div>
  );
}
