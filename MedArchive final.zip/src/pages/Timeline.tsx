import { useEffect, useState } from "react";
import { useLocation } from "react-router-dom";
import { supabase } from "../lib/supabase";
import type { MedicalRecord } from "../lib/types";
import Layout from "../components/Layout";
import {
  Clock,
  ChevronDown,
  ChevronUp,
  Pill,
  AlertTriangle,
  FileText,
  User,
  Upload,
  CheckCircle,
} from "lucide-react";
import { Link } from "react-router-dom";

function RecordCard({ record }: { record: MedicalRecord }) {
  const [expanded, setExpanded] = useState(false);
  const [docUrl, setDocUrl] = useState<string | null>(null);

  async function getDocUrl() {
    if (!record.document_url || docUrl) return;
    // document_url stores the storage path (e.g. "user-id/timestamp.jpg")
    const { data } = await supabase.storage
      .from("medical-documents")
      .createSignedUrl(record.document_url, 3600);
    setDocUrl(data?.signedUrl ?? null);
  }

  function toggle() {
    setExpanded(!expanded);
    if (!expanded) getDocUrl();
  }

  const formattedDate = record.consultation_date
    ? new Date(record.consultation_date + "T12:00:00").toLocaleDateString("en-GB", {
        weekday: "long",
        day: "numeric",
        month: "long",
        year: "numeric",
      })
    : null;

  return (
    <div
      className="rounded-2xl border overflow-hidden transition-shadow hover:shadow-sm"
      style={{ background: "var(--color-card)", borderColor: "var(--color-border)" }}
    >
      {/* Card header */}
      <button
        onClick={toggle}
        className="w-full text-left p-5 flex items-start gap-4"
      >
        {/* Date badge */}
        <div
          className="shrink-0 w-12 h-12 rounded-xl flex flex-col items-center justify-center"
          style={{ background: "var(--color-secondary)" }}
        >
          {record.consultation_date ? (
            <>
              <span className="text-xs font-semibold" style={{ color: "var(--color-primary)" }}>
                {new Date(record.consultation_date + "T12:00:00").toLocaleDateString("en-GB", { month: "short" }).toUpperCase()}
              </span>
              <span className="text-base font-bold leading-none" style={{ color: "var(--color-primary)" }}>
                {new Date(record.consultation_date + "T12:00:00").getDate()}
              </span>
            </>
          ) : (
            <Clock size={18} style={{ color: "var(--color-primary)" }} />
          )}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 flex-wrap mb-1">
            {formattedDate && (
              <span className="font-semibold text-sm" style={{ color: "var(--color-foreground)" }}>
                {formattedDate}
              </span>
            )}
            {record.doctor_name && (
              <span
                className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full"
                style={{ background: "var(--color-muted)", color: "var(--color-muted-foreground)" }}
              >
                <User size={10} />
                {record.doctor_name}
              </span>
            )}
          </div>

          {/* Quick summary */}
          <div className="flex flex-wrap gap-1.5 mt-2">
            {record.symptoms?.slice(0, 3).map((s) => (
              <span key={s} className="tag" style={{ background: "#fef3c7", color: "#92400e" }}>
                {s}
              </span>
            ))}
            {record.medicines?.slice(0, 2).map((m) => (
              <span key={m.name} className="tag" style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}>
                <Pill size={10} /> {m.name}
              </span>
            ))}
            {record.reactions?.length > 0 && (
              <span className="tag" style={{ background: "#fef2f2", color: "#dc2626" }}>
                <AlertTriangle size={10} /> {record.reactions.length} reaction{record.reactions.length > 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>

        <div className="shrink-0 mt-1" style={{ color: "var(--color-muted-foreground)" }}>
          {expanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
        </div>
      </button>

      {/* Expanded content */}
      {expanded && (
        <div className="px-5 pb-5 pt-0 border-t space-y-4" style={{ borderColor: "var(--color-border)" }}>

          {/* AI summary */}
          {record.summary && (
            <div className="pt-4 px-3 py-2.5 rounded-xl text-sm leading-relaxed"
              style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}>
              {record.summary}
            </div>
          )}

          <div className="pt-2 grid gap-4 sm:grid-cols-2">
            {/* Diagnosis */}
            {record.diagnosis && (
              <div className="sm:col-span-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider mb-1" style={{ color: "var(--color-muted-foreground)" }}>
                  Diagnosis
                </h4>
                <p className="text-sm font-medium" style={{ color: "var(--color-foreground)" }}>{record.diagnosis}</p>
              </div>
            )}

            {/* Symptoms */}
            {record.symptoms?.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--color-muted-foreground)" }}>
                  Symptoms
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {record.symptoms.map((s) => (
                    <span key={s} className="tag" style={{ background: "#fef3c7", color: "#92400e" }}>{s}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Reactions */}
            {record.reactions?.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "#dc2626" }}>
                  Reported reactions
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {record.reactions.map((r) => (
                    <span key={r} className="tag" style={{ background: "#fef2f2", color: "#dc2626" }}>
                      <AlertTriangle size={10} /> {r}
                    </span>
                  ))}
                </div>
              </div>
            )}

            {/* Key findings */}
            {record.key_findings?.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--color-muted-foreground)" }}>
                  Key findings
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {record.key_findings.map((f) => (
                    <span key={f} className="tag" style={{ background: "#eff6ff", color: "#1d4ed8" }}>{f}</span>
                  ))}
                </div>
              </div>
            )}

            {/* Abnormal results */}
            {record.abnormal_results?.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "#dc2626" }}>
                  Abnormal results
                </h4>
                <div className="flex flex-wrap gap-1.5">
                  {record.abnormal_results.map((r) => (
                    <span key={r} className="tag" style={{ background: "#fef2f2", color: "#dc2626" }}>{r}</span>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Medicines */}
          {record.medicines?.length > 0 && (
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--color-muted-foreground)" }}>
                Medicines prescribed
              </h4>
              <div className="space-y-2">
                {record.medicines.map((m, i) => (
                  <div
                    key={i}
                    className="flex items-start gap-3 px-3 py-2.5 rounded-xl"
                    style={{ background: "var(--color-muted)" }}
                  >
                    <Pill size={14} className="shrink-0 mt-0.5" style={{ color: "var(--color-primary)" }} />
                    <div>
                      <span className="font-medium text-sm" style={{ color: "var(--color-foreground)" }}>{m.name}</span>
                      {m.dosage && (
                        <span className="text-sm ml-2" style={{ color: "var(--color-muted-foreground)" }}>{m.dosage}</span>
                      )}
                      {(m.instructions || m.frequency) && (
                        <p className="text-xs mt-0.5" style={{ color: "var(--color-muted-foreground)" }}>
                          {[m.instructions, m.frequency].filter(Boolean).join(" · ")}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Notes */}
          {record.consultation_notes && (
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--color-muted-foreground)" }}>
                Consultation notes
              </h4>
              <p
                className="text-sm leading-relaxed px-3 py-2.5 rounded-xl"
                style={{ background: "var(--color-muted)", color: "var(--color-foreground)" }}
              >
                {record.consultation_notes}
              </p>
            </div>
          )}

          {/* Original document */}
          {record.document_url && (
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider mb-2" style={{ color: "var(--color-muted-foreground)" }}>
                Original document
              </h4>
              {docUrl ? (
                record.document_type?.startsWith("image/") ? (
                  <img
                    src={docUrl}
                    alt="Original document"
                    className="rounded-xl border max-h-64 object-contain"
                    style={{ borderColor: "var(--color-border)" }}
                  />
                ) : (
                  <a
                    href={docUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="inline-flex items-center gap-2 px-3 py-2 rounded-xl text-sm font-medium"
                    style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}
                  >
                    <FileText size={14} />
                    {record.document_name ?? "View document"}
                  </a>
                )
              ) : (
                <div className="text-sm" style={{ color: "var(--color-muted-foreground)" }}>Loading document...</div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

export default function Timeline() {
  const [records, setRecords] = useState<MedicalRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const location = useLocation();
  const justSaved = location.state?.saved;

  useEffect(() => {
    async function load() {
      const { data } = await supabase
        .from("medical_records")
        .select("*")
        .order("consultation_date", { ascending: false, nullsFirst: false })
        .order("created_at", { ascending: false });
      setRecords((data as MedicalRecord[]) ?? []);
      setLoading(false);
    }
    load();
  }, []);

  return (
    <Layout>
      <div className="max-w-2xl mx-auto space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-semibold mb-1" style={{ color: "var(--color-foreground)" }}>
              Your timeline
            </h1>
            <p style={{ color: "var(--color-muted-foreground)" }}>
              {records.length} consultation{records.length !== 1 ? "s" : ""} saved.
            </p>
          </div>
          <Link
            to="/upload"
            className="flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium"
            style={{ background: "var(--color-primary)", color: "white" }}
          >
            <Upload size={14} />
            Add
          </Link>
        </div>

        {justSaved && (
          <div
            className="flex items-center gap-2 p-3 rounded-xl text-sm animate-slide-up"
            style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}
          >
            <CheckCircle size={15} />
            Record saved to your timeline.
          </div>
        )}

        {loading ? (
          <div className="space-y-4">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-28 rounded-2xl animate-pulse" style={{ background: "var(--color-muted)" }} />
            ))}
          </div>
        ) : records.length === 0 ? (
          <div
            className="rounded-2xl border-2 border-dashed p-14 text-center"
            style={{ borderColor: "var(--color-border)" }}
          >
            <Clock size={32} className="mx-auto mb-3 opacity-30" style={{ color: "var(--color-muted-foreground)" }} />
            <p className="font-medium mb-1" style={{ color: "var(--color-foreground)" }}>Timeline is empty</p>
            <p className="text-sm mb-5" style={{ color: "var(--color-muted-foreground)" }}>
              Upload your first document to start your medical timeline.
            </p>
            <Link
              to="/upload"
              className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl text-sm font-medium"
              style={{ background: "var(--color-primary)", color: "white" }}
            >
              <Upload size={14} />
              Upload document
            </Link>
          </div>
        ) : (
          <div className="space-y-4">
            {records.map((r) => (
              <RecordCard key={r.id} record={r} />
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
