import { useState, useRef, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { supabase, STORAGE_BUCKET } from "../lib/supabase";
import type { SummarizeResult } from "../lib/types";
import Layout from "../components/Layout";
import {
  Upload as UploadIcon,
  FileText,
  Image,
  AlertCircle,
  Sparkles,
  X,
  CheckCircle,
} from "lucide-react";

const ACCEPTED_TYPES = [
  "image/jpeg",
  "image/png",
  "image/webp",
  "image/heic",
  "application/pdf",
];
const MAX_SIZE_MB = 10;

type Step = "idle" | "uploading" | "creating-record" | "extracting" | "done" | "error";

const STEP_LABELS: Record<Step, string> = {
  idle: "",
  uploading: "Uploading to secure storage…",
  "creating-record": "Creating record…",
  extracting: "Extracting information with AI…",
  done: "Done",
  error: "",
};

export default function Upload() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [dragging, setDragging] = useState(false);
  const [step, setStep] = useState<Step>("idle");
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const navigate = useNavigate();

  function handleFile(f: File) {
    setError(null);
    if (!ACCEPTED_TYPES.includes(f.type)) {
      setError("Please upload a JPG, PNG, WebP, or PDF file.");
      return;
    }
    if (f.size > MAX_SIZE_MB * 1024 * 1024) {
      setError(`File must be under ${MAX_SIZE_MB} MB.`);
      return;
    }
    setFile(f);
    setPreview(f.type.startsWith("image/") ? URL.createObjectURL(f) : null);
    setError(null);
    setStep("idle");
  }

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragging(false);
    const dropped = e.dataTransfer.files[0];
    if (dropped) handleFile(dropped);
  }, []);

  async function handleExtract() {
    if (!file) return;
    setError(null);

    // ── Step 1: authenticate ─────────────────────────────────────────────
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) {
      setError("You must be logged in to upload documents.");
      return;
    }

    // ── Step 2: upload file to private Storage ───────────────────────────
    setStep("uploading");
    const ext = file.name.split(".").pop() ?? "bin";
    const storagePath = `${user.id}/${Date.now()}.${ext}`;

    const { error: uploadErr } = await supabase.storage
      .from(STORAGE_BUCKET)
      .upload(storagePath, file, { upsert: false });

    if (uploadErr) {
      setError(`Storage upload failed: ${uploadErr.message}`);
      setStep("error");
      return;
    }

    // ── Step 3: insert a draft medical_records row ───────────────────────
    setStep("creating-record");
    const { data: record, error: insertErr } = await supabase
      .from("medical_records")
      .insert({
        user_id: user.id,
        document_url: storagePath,
        document_name: file.name,
        document_type: file.type,
        symptoms: [],
        medicines: [],
        reactions: [],
        key_findings: [],
        abnormal_results: [],
      })
      .select("id")
      .single();

    if (insertErr || !record) {
      setError(`Failed to create record: ${insertErr?.message ?? "unknown error"}`);
      setStep("error");
      return;
    }

    // ── Step 4: invoke summarize-report edge function ────────────────────
    setStep("extracting");

    const { data: extracted, error: fnErr } = await supabase.functions.invoke<SummarizeResult>(
      "summarize-report",
      {
        body: {
          record_id: record.id,
          document_name: file.name,
          storage_path: storagePath,   // the actual Storage path, not the display filename
          mime_type: file.type,
        },
      },
    );

    // Build the error string from the edge function response
    let extractionError: string | null = null;
    if (fnErr) {
      // fnErr.message is often generic; try to get the actual body
      const msg =
        typeof (fnErr as { context?: { error?: string } }).context?.error === "string"
          ? (fnErr as { context?: { error?: string } }).context!.error!
          : fnErr.message;
      extractionError = msg ?? "Edge function returned an error.";
    }

    setStep("done");

    // ── Step 5: navigate to Review with record_id and extracted data ─────
    navigate("/review", {
      state: {
        recordId: record.id,
        extractedData: extractionError ? null : (extracted ?? null),
        extractionError,
        documentName: file.name,
        documentType: file.type,
        storagePath,
      },
    });
  }

  const busy = step !== "idle" && step !== "error" && step !== "done";

  return (
    <Layout>
      <div className="max-w-xl mx-auto space-y-6">
        <div>
          <h1
            className="text-2xl font-semibold mb-1"
            style={{ color: "var(--color-foreground)" }}
          >
            Upload a document
          </h1>
          <p style={{ color: "var(--color-muted-foreground)" }}>
            A prescription, medical note, or any document from your consultation.
          </p>
        </div>

        {/* Error banner */}
        {error && (
          <div
            className="flex items-start gap-2 p-3 rounded-xl text-sm"
            style={{ background: "#fef2f2", color: "#dc2626", border: "1px solid #fecaca" }}
          >
            <AlertCircle size={15} className="shrink-0 mt-0.5" />
            {error}
          </div>
        )}

        {/* Drop zone */}
        <div
          onClick={() => !file && !busy && fileInputRef.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            if (!busy) setDragging(true);
          }}
          onDragLeave={() => setDragging(false)}
          onDrop={onDrop}
          className="rounded-2xl border-2 border-dashed transition-all"
          style={{
            borderColor: dragging
              ? "var(--color-primary)"
              : "var(--color-border)",
            background: dragging
              ? "var(--color-secondary)"
              : file
              ? "var(--color-muted)"
              : "transparent",
            cursor: file || busy ? "default" : "pointer",
          }}
        >
          {file ? (
            <div className="p-5">
              <div className="flex items-start gap-3">
                {preview ? (
                  <img
                    src={preview}
                    alt="Document preview"
                    className="w-20 h-24 object-cover rounded-lg border shrink-0"
                    style={{ borderColor: "var(--color-border)" }}
                  />
                ) : (
                  <div
                    className="w-20 h-24 rounded-lg border flex items-center justify-center shrink-0"
                    style={{
                      borderColor: "var(--color-border)",
                      background: "var(--color-secondary)",
                    }}
                  >
                    <FileText size={24} style={{ color: "var(--color-primary)" }} />
                  </div>
                )}
                <div className="flex-1 min-w-0">
                  <p
                    className="font-medium text-sm truncate"
                    style={{ color: "var(--color-foreground)" }}
                  >
                    {file.name}
                  </p>
                  <p
                    className="text-xs mt-1"
                    style={{ color: "var(--color-muted-foreground)" }}
                  >
                    {(file.size / 1024 / 1024).toFixed(2)} MB ·{" "}
                    {file.type.includes("pdf") ? "PDF" : "Image"}
                  </p>
                  {!busy && (
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        setFile(null);
                        setPreview(null);
                        setStep("idle");
                        setError(null);
                      }}
                      className="mt-3 flex items-center gap-1 text-xs font-medium"
                      style={{ color: "var(--color-muted-foreground)" }}
                    >
                      <X size={12} /> Remove
                    </button>
                  )}
                </div>
              </div>
            </div>
          ) : (
            <div className="py-14 px-6 text-center">
              <div
                className="w-12 h-12 rounded-2xl flex items-center justify-center mx-auto mb-4"
                style={{ background: "var(--color-secondary)" }}
              >
                <UploadIcon size={22} style={{ color: "var(--color-primary)" }} />
              </div>
              <p className="font-medium mb-1" style={{ color: "var(--color-foreground)" }}>
                Drop your document here
              </p>
              <p className="text-sm" style={{ color: "var(--color-muted-foreground)" }}>
                or{" "}
                <span style={{ color: "var(--color-primary)" }}>browse to choose a file</span>
              </p>
              <p className="text-xs mt-3" style={{ color: "var(--color-muted-foreground)" }}>
                JPG, PNG, WebP, or PDF · Max {MAX_SIZE_MB} MB
              </p>
            </div>
          )}
        </div>

        <input
          ref={fileInputRef}
          type="file"
          accept={ACCEPTED_TYPES.join(",")}
          className="hidden"
          onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
        />

        {/* File type hints */}
        <div className="flex gap-4 flex-wrap">
          {[
            { icon: Image, label: "Photo of prescription" },
            { icon: FileText, label: "Scanned document" },
            { icon: FileText, label: "PDF report" },
          ].map(({ icon: Icon, label }) => (
            <div
              key={label}
              className="flex items-center gap-1.5 text-xs"
              style={{ color: "var(--color-muted-foreground)" }}
            >
              <Icon size={13} />
              {label}
            </div>
          ))}
        </div>

        {/* Progress + CTA */}
        {file && (
          <div className="space-y-3 animate-slide-up">
            {/* Step progress */}
            {busy && (
              <div
                className="flex items-center gap-2 px-4 py-3 rounded-xl text-sm"
                style={{ background: "var(--color-secondary)", color: "var(--color-secondary-foreground)" }}
              >
                <div
                  className="w-4 h-4 border-2 border-t-transparent rounded-full animate-spin shrink-0"
                  style={{
                    borderColor: "var(--color-primary)",
                    borderTopColor: "transparent",
                  }}
                />
                {STEP_LABELS[step]}
              </div>
            )}

            {/* Steps checklist once extracting */}
            {(busy || step === "done") && (
              <div className="space-y-1.5 px-1">
                {(
                  [
                    { key: "uploading", label: "File saved to private storage" },
                    { key: "creating-record", label: "Medical record created" },
                    { key: "extracting", label: "AI extraction via Gemini" },
                  ] as const
                ).map(({ key, label }) => {
                  const steps: Step[] = ["uploading", "creating-record", "extracting", "done"];
                  const stepIndex = steps.indexOf(key);
                  const currentIndex = steps.indexOf(step);
                  const done = currentIndex > stepIndex;
                  const active = currentIndex === stepIndex;

                  return (
                    <div key={key} className="flex items-center gap-2 text-sm">
                      {done ? (
                        <CheckCircle size={14} style={{ color: "var(--color-primary)" }} />
                      ) : active ? (
                        <div
                          className="w-3.5 h-3.5 border-2 border-t-transparent rounded-full animate-spin"
                          style={{
                            borderColor: "var(--color-primary)",
                            borderTopColor: "transparent",
                          }}
                        />
                      ) : (
                        <div
                          className="w-3.5 h-3.5 rounded-full border-2"
                          style={{ borderColor: "var(--color-border)" }}
                        />
                      )}
                      <span
                        style={{
                          color: done
                            ? "var(--color-foreground)"
                            : active
                            ? "var(--color-foreground)"
                            : "var(--color-muted-foreground)",
                        }}
                      >
                        {label}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}

            {!busy && step !== "done" && (
              <button
                onClick={handleExtract}
                disabled={busy}
                className="w-full flex items-center justify-center gap-2 py-3 rounded-xl font-medium transition-opacity hover:opacity-90 disabled:opacity-60"
                style={{ background: "var(--color-primary)", color: "white" }}
              >
                <Sparkles size={16} />
                Extract &amp; Review
              </button>
            )}

            <p className="text-xs text-center" style={{ color: "var(--color-muted-foreground)" }}>
              AI results are never saved automatically — you review and approve first.
            </p>
          </div>
        )}

        {/* Privacy note */}
        <div
          className="rounded-xl p-4 text-sm"
          style={{ background: "var(--color-muted)", color: "var(--color-muted-foreground)" }}
        >
          <strong
            className="block mb-1"
            style={{ color: "var(--color-foreground)" }}
          >
            Your documents are private.
          </strong>
          Files are stored in a private Supabase Storage bucket with Row Level Security — only you
          can access them.
        </div>
      </div>
    </Layout>
  );
}
