import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "jsr:@supabase/supabase-js@2.49.8";
import * as kv from "./kv_store.tsx";
import { SAMPLE_RECORDS } from "./seed.tsx";

const app = new Hono();

app.use("*", logger(console.log));

app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check
app.get("/make-server-7c00bccb/health", (c) => {
  return c.json({ status: "ok" });
});

// Helper: verify Supabase JWT and return user
async function getUser(authHeader: string | null) {
  if (!authHeader?.startsWith("Bearer ")) return null;
  const token = authHeader.slice(7);
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY") ?? Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  );
  const { data: { user }, error } = await supabase.auth.getUser(token);
  if (error || !user) return null;
  return user;
}

const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

const EXTRACTION_PROMPT = `You are a medical document parser. Analyze the provided medical document image and extract information strictly from what is visible.

CRITICAL RULES:
- Only extract information that is clearly visible in the document
- If a field cannot be clearly read, use null (for strings) or [] (for arrays)
- Never guess, infer, or hallucinate any information
- For medicines, only list what is explicitly written
- For reactions, only list adverse effects explicitly mentioned in the document

Return ONLY valid JSON with no markdown formatting, matching this exact schema:
{
  "consultation_date": "YYYY-MM-DD or null",
  "doctor_name": "string or null",
  "symptoms": ["array of symptom strings, or empty array"],
  "medicines": [{"name": "string", "dosage": "string or empty string", "instructions": "string or empty string", "frequency": "string or empty string"}],
  "reactions": ["reported adverse reactions explicitly in document, or empty array"],
  "consultation_notes": "any additional clinical notes visible, or null"
}`;

const MEMORY_SYSTEM_PROMPT = `You are MedArchive's medical memory assistant. Your ONLY job is to help users recall information from their verified, saved medical records.

STRICT RULES:
1. Answer ONLY from the medical records provided below
2. Never infer, guess, or add information not in the records
3. Never give medical advice, diagnoses, or recommendations
4. Never suggest changing, starting, or stopping medication
5. Use "Reported reaction" — not "allergy" — unless the document explicitly says allergy
6. If the requested information is not in the records, say exactly: "I couldn't find that information in your saved medical history."
7. Keep answers concise and factual

VERIFIED MEDICAL RECORDS:
`;

// POST /make-server-7c00bccb/gemini/extract
// Body: { fileData: string (base64), mimeType: string }
// Returns: ExtractedData JSON
app.post("/make-server-7c00bccb/gemini/extract", async (c) => {
  const user = await getUser(c.req.header("Authorization") ?? null);
  if (!user) return c.json({ error: "Unauthorized" }, 401);

  const geminiKey = Deno.env.get("GEMINI_API_KEY");
  if (!geminiKey) return c.json({ error: "Gemini API key not configured on server. Add GEMINI_API_KEY to Supabase Edge Function secrets." }, 503);

  let body: { fileData: string; mimeType: string };
  try {
    body = await c.req.json();
  } catch {
    return c.json({ error: "Invalid request body" }, 400);
  }

  const { fileData, mimeType } = body;
  if (!fileData || !mimeType) {
    return c.json({ error: "fileData and mimeType are required" }, 400);
  }

  try {
    const res = await fetch(`${GEMINI_URL}?key=${geminiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [
            { text: EXTRACTION_PROMPT },
            { inline_data: { mime_type: mimeType, data: fileData } },
          ],
        }],
        generationConfig: { temperature: 0.1, maxOutputTokens: 1024 },
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      return c.json({ error: `Gemini error: ${err}` }, 502);
    }

    const data = await res.json();
    const text = data?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";
    const cleaned = text.replace(/```json\n?/g, "").replace(/```\n?/g, "").trim();

    try {
      const parsed = JSON.parse(cleaned);
      return c.json({
        consultation_date: parsed.consultation_date ?? null,
        doctor_name: parsed.doctor_name ?? null,
        symptoms: Array.isArray(parsed.symptoms) ? parsed.symptoms : [],
        medicines: Array.isArray(parsed.medicines) ? parsed.medicines : [],
        reactions: Array.isArray(parsed.reactions) ? parsed.reactions : [],
        consultation_notes: parsed.consultation_notes ?? null,
      });
    } catch {
      return c.json({ error: "Failed to parse AI response" }, 502);
    }
  } catch (err) {
    return c.json({ error: String(err) }, 500);
  }
});

// POST /make-server-7c00bccb/gemini/memory
// Body: { question: string, recordsContext: string }
// Returns: { answer: string }
app.post("/make-server-7c00bccb/gemini/memory", async (c) => {
  const user = await getUser(c.req.header("Authorization") ?? null);
  if (!user) return c.json({ error: "Unauthorized" }, 401);

  const geminiKey = Deno.env.get("GEMINI_API_KEY");
  if (!geminiKey) return c.json({ error: "Gemini API key not configured on server. Add GEMINI_API_KEY to Supabase Edge Function secrets." }, 503);

  let body: { question: string; recordsContext: string };
  try {
    body = await c.req.json();
  } catch {
    return c.json({ error: "Invalid request body" }, 400);
  }

  const { question, recordsContext } = body;
  if (!question) return c.json({ error: "question is required" }, 400);

  try {
    const res = await fetch(`${GEMINI_URL}?key=${geminiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [{
            text: MEMORY_SYSTEM_PROMPT +
              (recordsContext || "No medical records found.") +
              "\n\nUser question: " + question,
          }],
        }],
        generationConfig: { temperature: 0.2, maxOutputTokens: 512 },
      }),
    });

    if (!res.ok) {
      const err = await res.text();
      return c.json({ error: `Gemini error: ${err}` }, 502);
    }

    const data = await res.json();
    const answer = data?.candidates?.[0]?.content?.parts?.[0]?.text ??
      "I couldn't find that information in your saved medical history.";

    return c.json({ answer });
  } catch (err) {
    return c.json({ error: String(err) }, 500);
  }
});

// POST /make-server-7c00bccb/seed
// Seeds sample medical records for the demo user using the service role key.
// Remove this route after seeding.
app.post("/make-server-7c00bccb/seed", async (c) => {
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY");
  if (!serviceKey) return c.json({ error: "Service role key not available" }, 503);

  const admin = createClient(
    Deno.env.get("SUPABASE_URL")!,
    serviceKey,
    { auth: { autoRefreshToken: false, persistSession: false } }
  );

  // Clear any existing sample records for this user first
  await admin
    .from("medical_records")
    .delete()
    .eq("user_id", SAMPLE_RECORDS[0].user_id);

  const { data, error } = await admin
    .from("medical_records")
    .insert(SAMPLE_RECORDS)
    .select("id, consultation_date, doctor_name");

  if (error) return c.json({ error: error.message }, 500);
  return c.json({ seeded: data?.length ?? 0, records: data });
});

Deno.serve(app.fetch);
