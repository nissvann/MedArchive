// Seed data for user ee88e5c7-ef50-49c6-a460-8b48caf0f11b
// Called via POST /make-server-7c00bccb/seed  (no auth required — remove after seeding)

export const USER_ID = "ee88e5c7-ef50-49c6-a460-8b48caf0f11b";

export const SAMPLE_RECORDS = [
  {
    user_id: USER_ID,
    consultation_date: "2024-03-12",
    doctor_name: "Dr. Sarah Mitchell",
    symptoms: ["sore throat", "fever", "fatigue", "dry cough", "swollen lymph nodes"],
    medicines: [
      { name: "Amoxicillin", dosage: "500mg", instructions: "Take with food", frequency: "3 times daily for 7 days" },
      { name: "Paracetamol", dosage: "500mg", instructions: "Take when temperature above 38°C", frequency: "Every 6 hours as needed" },
      { name: "Difflam Throat Spray", dosage: "As directed", instructions: "Spray directly to throat", frequency: "Every 3 hours" },
    ],
    reactions: [],
    consultation_notes:
      "Bacterial tonsillitis confirmed. Temperature 38.8°C at time of visit. Advised complete 7-day antibiotic course even if symptoms improve. Rest for minimum 5 days. Return immediately if rash develops or difficulty swallowing worsens. Follow up in 2 weeks if symptoms persist.",
  },
  {
    user_id: USER_ID,
    consultation_date: "2024-06-04",
    doctor_name: "Dr. James Okafor",
    symptoms: ["mild persistent headache", "elevated blood pressure", "occasional blurred vision"],
    medicines: [
      { name: "Amlodipine", dosage: "5mg", instructions: "Take in the morning", frequency: "Once daily" },
      { name: "Vitamin D3", dosage: "1000 IU", instructions: "Take with a meal", frequency: "Once daily" },
    ],
    reactions: [],
    consultation_notes:
      "Blood pressure recorded at 145/92 mmHg. Annual health review. BMI 26.4. Cholesterol borderline — advised dietary changes. Low-sodium diet recommended. Reduce caffeine. 30 min light exercise daily. ECG normal. Return in 3 months for BP review.",
  },
  {
    user_id: USER_ID,
    consultation_date: "2024-08-19",
    doctor_name: "Dr. Sarah Mitchell",
    symptoms: ["widespread skin rash", "itching", "mild facial swelling", "hives on arms and torso"],
    medicines: [
      { name: "Cetirizine", dosage: "10mg", instructions: "Take at night", frequency: "Once daily for 7 days" },
      { name: "Hydrocortisone cream 1%", dosage: "Topical", instructions: "Apply thin layer to affected areas", frequency: "Twice daily, not on face" },
    ],
    reactions: [
      "Skin rash and hives following Amoxicillin course — possible penicillin-class sensitivity",
    ],
    consultation_notes:
      "Patient presented 2 days after completing Amoxicillin course with generalised urticarial rash. Likely drug reaction — penicillin sensitivity suspected. Referred for allergy testing. IMPORTANT: Avoid all penicillin-class antibiotics (Amoxicillin, Ampicillin, Flucloxacillin) until allergy confirmed by testing. Document in patient notes.",
  },
  {
    user_id: USER_ID,
    consultation_date: "2024-10-22",
    doctor_name: "Dr. James Okafor",
    symptoms: ["occasional dizziness on standing", "mild fatigue", "mild ankle swelling"],
    medicines: [
      { name: "Amlodipine", dosage: "5mg", instructions: "Take in the morning", frequency: "Once daily (continued)" },
      { name: "Magnesium Glycinate", dosage: "200mg", instructions: "Take at bedtime", frequency: "Once daily" },
    ],
    reactions: [],
    consultation_notes:
      "Blood pressure improved to 132/84 mmHg — good response to Amlodipine. Ankle swelling is a known side effect of Amlodipine, monitoring for now. Dizziness likely postural hypotension — advised to rise slowly. Fatigue possibly related to borderline Vitamin D. Continue current medications. Next BP review January 2025.",
  },
  {
    user_id: USER_ID,
    consultation_date: "2025-01-08",
    doctor_name: "Dr. Priya Sharma",
    symptoms: ["nausea", "vomiting", "watery diarrhoea", "abdominal cramps", "mild dehydration"],
    medicines: [
      { name: "Oral Rehydration Salts (Dioralyte)", dosage: "1 sachet per 200ml water", instructions: "Sip slowly throughout the day", frequency: "After each loose stool or vomiting episode" },
      { name: "Loperamide", dosage: "2mg", instructions: "Take after loose stool", frequency: "Max 8mg (4 tablets) per day, max 2 days" },
      { name: "Domperidone", dosage: "10mg", instructions: "Take 30 min before meals", frequency: "3 times daily for 3 days" },
    ],
    reactions: [],
    consultation_notes:
      "Acute viral gastroenteritis. Onset 48 hours ago following suspected contaminated food. No blood in stool. Mild dehydration — advised clear fluids, oral rehydration salts. Bland BRAT diet for 48 hours (bananas, rice, apple, toast). Avoid dairy, fatty foods for 5 days. Return if symptoms beyond 5 days or blood in stool.",
  },
  {
    user_id: USER_ID,
    consultation_date: "2025-04-14",
    doctor_name: "Dr. James Okafor",
    symptoms: ["lower back pain", "muscle stiffness", "fatigue after prolonged sitting"],
    medicines: [
      { name: "Ibuprofen", dosage: "400mg", instructions: "Take with food — do not take on empty stomach", frequency: "3 times daily for 5 days only" },
      { name: "Omeprazole", dosage: "20mg", instructions: "Take 30 min before breakfast", frequency: "Once daily while on Ibuprofen" },
    ],
    reactions: [],
    consultation_notes:
      "Blood pressure excellent at 128/80 mmHg — continue Amlodipine. Lower back pain assessed as mechanical/muscular, likely due to prolonged desk work. No neurological signs. Omeprazole prescribed as stomach protection alongside Ibuprofen. Referred to NHS physiotherapy for posture assessment. Advised stretching, core strengthening. Annual blood panel ordered.",
  },
];
