import { createClient } from "jsr:@supabase/supabase-js@2.49.8";

const GEMINI_URL =
  "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent";

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS, "Content-Type": "application/json" },
  });
}

const EXTRACTION_PROMPT = `You are a precise medical document parser. Analyze the provided medical document and extract every piece of information that is clearly visible.

STRICT RULES:
- Only extract information explicitly visible in the document. Never guess or infer.
- If a field cannot be clearly read, use null for strings, [] for arrays.
- Do not fabricate doctor names, dates, medicines, or results.
- Use "reported reaction" language — not "allergy" — unless the document explicitly says "allergy".
- For medications, capture name, dosage, instructions, and frequency exactly as written.
- For key_findings and abnormal_results, extract lab values, vitals, or clinical observations if present.
- summary should be 1-2 sentences describing what this document is about.

Return ONLY valid JSON — no markdown, no explanation — matching this exact schema:
{
  "consultation_date": "YYYY-MM-DD or null",
  "doctor_name": "full name as written or null",
  "symptoms": ["patient-reported symptoms as listed"],
  "diagnosis": "diagnosis or clinical impression as written, or null",
  "consultation_notes": "clinical notes, advice given, follow-up instructions, or null",
  "medications": [
    {
      "name": "medicine name",
      "dosage": "dosage as written or empty string",
      "instructions": "how to take it or empty string",
      "frequency": "how often or empty string"
    }
  ],
  "reactions": ["adverse reactions or side effects explicitly mentioned, or empty array"],
  "summary": "1-2 sentence plain-language summary of this document, or null",
  "key_findings": ["notable clinical findings, test results, vitals — or empty array"],
  "abnormal_results": ["any results flagged as abnormal, high, low, or concerning — or empty array"]
}`;

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: CORS });
  }

  // ── 1. Auth ──────────────────────────────────────────────────────────────
  const authHeader = req.headers.get("Authorization") ?? "";
  if (!authHeader.startsWith("Bearer ")) {
    return json({ error: "Missing or invalid Authorization header" }, 401);
  }
  const jwt = authHeader.slice(7);

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;
  const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
  const geminiKey = Deno.env.get("GEMINI_API_KEY");

  if (!geminiKey) {
    return json(
      { error: "GEMINI_API_KEY is not set in Edge Function secrets. Add it in the Supabase dashboard → Edge Functions → Secrets." },
      503,
    );
  }

  // Verify the JWT and get the user
  const authClient = createClient(supabaseUrl, anonKey);
  const { data: { user }, error: authErr } = await authClient.auth.getUser(jwt);
  if (authErr || !user) {
    return json({ error: "Unauthorized: invalid or expired session" }, 401);
  }

  // ── 2. Parse request body ─────────────────────────────────────────────────
  let body: {
    record_id: string;
    document_name: string;
    storage_path: string;
    mime_type: string;
  };

  try {
    body = await req.json();
  } catch {
    return json({ error: "Invalid JSON request body" }, 400);
  }

  const { record_id, document_name, storage_path, mime_type } = body;

  if (!record_id || !storage_path || !mime_type) {
    return json(
      { error: "record_id, storage_path, and mime_type are required" },
      400,
    );
  }

  // ── 3. Verify record ownership ────────────────────────────────────────────
  const adminClient = createClient(supabaseUrl, serviceKey, {
    auth: { autoRefreshToken: false, persistSession: false },
  });

  const { data: record, error: recordErr } = await adminClient
    .from("medical_records")
    .select("id, user_id")
    .eq("id", record_id)
    .single();

  if (recordErr || !record) {
    return json({ error: `Record not found: ${recordErr?.message ?? "unknown"}` }, 404);
  }
  if (record.user_id !== user.id) {
    return json({ error: "Access denied: this record belongs to another user" }, 403);
  }

  // ── 4. Download file from private Storage ─────────────────────────────────
  // Use a user-scoped client so Storage RLS is respected
  const userStorageClient = createClient(supabaseUrl, anonKey, {
    global: { headers: { Authorization: `Bearer ${jwt}` } },
  });

  const { data: fileBlob, error: downloadErr } = await userStorageClient.storage
    .from("medical-documents")
    .download(storage_path);

  if (downloadErr || !fileBlob) {
    return json(
      { error: `Failed to download document from Storage: ${downloadErr?.message ?? "file not found"}. Check that the storage path is correct and Storage RLS policies are in place.` },
      500,
    );
  }

  // ── 5. Convert to base64 ──────────────────────────────────────────────────
  const arrayBuffer = await fileBlob.arrayBuffer();
  const uint8 = new Uint8Array(arrayBuffer);
  // Chunked btoa to avoid call-stack overflow on large files
  let binary = "";
  const CHUNK = 8192;
  for (let i = 0; i < uint8.length; i += CHUNK) {
    binary += String.fromCharCode(...uint8.subarray(i, i + CHUNK));
  }
  const base64Data = btoa(binary);

  // Gemini accepts application/pdf natively; images pass through as-is
  const geminiMime = mime_type === "application/pdf" ? "application/pdf" : mime_type;

  // ── 6. Call Gemini ────────────────────────────────────────────────────────
  let geminiRes: Response;
  try {
    geminiRes = await fetch(`${GEMINI_URL}?key=${geminiKey}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [
            { text: EXTRACTION_PROMPT },
            { inline_data: { mime_type: geminiMime, data: base64Data } },
          ],
        }],
        generationConfig: { temperature: 0.1, maxOutputTokens: 2048 },
      }),
    });
  } catch (fetchErr) {
    return json({ error: `Network error calling Gemini: ${String(fetchErr)}` }, 502);
  }

  if (!geminiRes.ok) {
    const errText = await geminiRes.text();
    return json(
      { error: `Gemini API returned ${geminiRes.status}: ${errText}` },
      502,
    );
  }

  const geminiData = await geminiRes.json();
  const rawText: string =
    geminiData?.candidates?.[0]?.content?.parts?.[0]?.text ?? "";

  if (!rawText) {
    return json({ error: "Gemini returned an empty response. The document may be unreadable or too low quality." }, 502);
  }

  // ── 7. Parse JSON from Gemini response ────────────────────────────────────
  const cleaned = rawText
    .replace(/^```json\s*/i, "")
    .replace(/^```\s*/i, "")
    .replace(/\s*```$/i, "")
    .trim();

  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(cleaned);
  } catch {
    return json(
      { error: `Gemini response could not be parsed as JSON. Raw response: ${rawText.slice(0, 500)}` },
      502,
    );
  }

  // ── 8. Return structured result ───────────────────────────────────────────
  return json({
    consultation_date: typeof parsed.consultation_date === "string" ? parsed.consultation_date : null,
    doctor_name: typeof parsed.doctor_name === "string" ? parsed.doctor_name : null,
    symptoms: Array.isArray(parsed.symptoms) ? parsed.symptoms.filter(Boolean) : [],
    diagnosis: typeof parsed.diagnosis === "string" ? parsed.diagnosis : null,
    consultation_notes: typeof parsed.consultation_notes === "string" ? parsed.consultation_notes : null,
    medications: Array.isArray(parsed.medications) ? parsed.medications : [],
    reactions: Array.isArray(parsed.reactions) ? parsed.reactions.filter(Boolean) : [],
    summary: typeof parsed.summary === "string" ? parsed.summary : null,
    key_findings: Array.isArray(parsed.key_findings) ? parsed.key_findings.filter(Boolean) : [],
    abnormal_results: Array.isArray(parsed.abnormal_results) ? parsed.abnormal_results.filter(Boolean) : [],
  });
});
